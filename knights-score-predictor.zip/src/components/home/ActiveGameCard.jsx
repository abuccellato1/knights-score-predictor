
import React, { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { Trophy, Users, Instagram, Crown, Shield } from "lucide-react";

import InstagramHandle from "./InstagramHandle";

export default function ActiveGameCard({ game, predictions = [], allPredictions = [], onDataUpdate, onFilterChange, activeFilters }) {
  const [currentPrediction, setCurrentPrediction] = useState(0);
  const [showWinner, setShowWinner] = useState(false);
  const [displayedWinner, setDisplayedWinner] = useState(null);

  const predictionCount = predictions.length;
  const winners = predictions.filter(p => p.is_winner);

  // Auto-scroll through predictions
  useEffect(() => {
    if (predictions.length === 0) return;

    const interval = setInterval(() => {
      setCurrentPrediction(prev => (prev + 1) % predictions.length);
    }, 3000); // Change every 3 seconds

    return () => clearInterval(interval);
  }, [predictions.length]);

  // Show winner when game is completed
  useEffect(() => {
    if (game.status === 'completed' && winners.length > 0) {
      // Randomly select one winner if multiple
      const randomWinner = winners[Math.floor(Math.random() * winners.length)];
      setDisplayedWinner(randomWinner);
      setShowWinner(true);
    } else {
      setShowWinner(false);
      setDisplayedWinner(null);
    }
  }, [game.status, winners.length, winners]);
  
  const FilterBadge = ({ filterType, value, children }) => (
    <Badge
      variant={activeFilters[filterType] === value ? "default" : "destructive"}
      onClick={() => onFilterChange(filterType, value)}
      className="cursor-pointer transition-colors bg-red-100 text-red-800 hover:bg-red-200"
    >
      {children}
    </Badge>
  );


  return (
    <Card className="relative overflow-hidden bg-gradient-to-br from-red-50 to-orange-50 border-2 border-red-300 shadow-lg">
      {/* Live Badge */}
      <div className="absolute top-3 right-3 z-10">
        <Badge className="bg-red-500 text-white animate-pulse">
          🔴 LIVE
        </Badge>
      </div>

      <CardContent className="p-6">
        {/* Game Header */}
        <div className="text-center mb-6">
           <div className="flex justify-center gap-2 flex-wrap mb-2">
                <FilterBadge filterType="sport" value={game.sport}>
                    <div className="flex items-center gap-1"><Trophy className="w-3 h-3" /> {game.sport}</div>
                </FilterBadge>
                 <FilterBadge filterType="gender" value={game.gender}>
                    <div className="flex items-center gap-1"><Users className="w-3 h-3" /> {game.gender}</div>
                </FilterBadge>
                 <FilterBadge filterType="level" value={game.level}>
                    <div className="flex items-center gap-1"><Shield className="w-3 h-3" /> {game.level}</div>
                </FilterBadge>
            </div>
          <p className="text-sm text-red-700 mb-2 font-semibold">
            LIVE GAME
          </p>
          <p className="text-lg font-semibold text-[#041e42]">
            {format(new Date(game.game_date), "MMM d, yyyy 'at' h:mm a")}
          </p>
        </div>

        {/* Scoreboard */}
        <div className="bg-gradient-to-r from-[#041e42] to-[#0a2a5c] rounded-lg p-6 text-white mb-6">
          <div className="grid grid-cols-3 items-center text-center">
            {/* Home Team */}
            <div>
              <p className="text-sm opacity-80">HOME</p>
              <p className="font-bold text-xl">{game.home_team}</p>
              {game.home_score !== null && (
                <p className="text-3xl font-bold text-yellow-400">{game.home_score}</p>
              )}
            </div>
            
            {/* VS or Score */}
            <div className="text-3xl font-bold">
              {game.home_score !== null ? '-' : 'VS'}
            </div>
            
            {/* Away Team */}
            <div>
              <p className="text-sm opacity-80">AWAY</p>
              <p className="font-bold text-xl">{game.away_team}</p>
              {game.away_score !== null && (
                <p className="text-3xl font-bold text-yellow-400">{game.away_score}</p>
              )}
            </div>
          </div>
        </div>

        {/* Winner Display or Scrolling Predictions */}
        {showWinner && displayedWinner ? (
          <div className="bg-gradient-to-r from-yellow-400 to-orange-400 rounded-lg p-6 text-center text-black mb-4">
            <div className="flex items-center justify-center gap-2 mb-4">
              <Crown className="w-8 h-8" />
              <h3 className="text-2xl font-bold">🏆 WINNER! 🏆</h3>
              <Crown className="w-8 h-8" />
            </div>
            <div className="space-y-2">
              <p className="text-lg font-semibold">
                <InstagramHandle handle={displayedWinner.instagram_handle} />
              </p>
              <p className="text-sm opacity-90">
                Predicted: {displayedWinner.predicted_home_score} - {displayedWinner.predicted_away_score}
              </p>
              <p className="text-sm opacity-90">
                Actual: {game.home_score} - {game.away_score}
              </p>
            </div>
          </div>
        ) : (
          <div className="bg-gradient-to-r from-blue-100 to-purple-100 rounded-lg p-4 mb-4">
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-semibold text-[#041e42]">Live Predictions</h4>
              <Badge className="bg-blue-600 text-white">
                {predictionCount} total
              </Badge>
            </div>
            
            {predictions.length > 0 ? (
              <div className="bg-white rounded-lg p-4 shadow-inner">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-gradient-to-r from-[#041e42] to-[#0a2a5c] rounded-full hidden sm:flex items-center justify-center">
                      <Instagram className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <p className="font-semibold text-[#041e42]">
                        <InstagramHandle handle={predictions[currentPrediction]?.instagram_handle} />
                      </p>
                      <p className="text-xs text-[#75787b]">
                        {format(new Date(predictions[currentPrediction]?.submitted_at), "MMM d, h:mm a")}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <div className="w-10 h-10 bg-[#041e42] text-white rounded flex items-center justify-center font-bold">
                      {predictions[currentPrediction]?.predicted_home_score}
                    </div>
                    <span className="text-[#75787b] font-bold">-</span>
                    <div className="w-10 h-10 bg-[#75787b] text-white rounded flex items-center justify-center font-bold">
                      {predictions[currentPrediction]?.predicted_away_score}
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center text-[#75787b] py-4">
                <p>No predictions yet for this game</p>
              </div>
            )}
          </div>
        )}

        {/* Game Stats */}
        <div className="flex justify-center gap-4 text-sm text-[#75787b]">
          <div className="flex items-center gap-1">
            <Users className="w-4 h-4" />
            <span>{predictionCount} predictions</span>
          </div>
          {winners.length > 0 && (
            <div className="flex items-center gap-1">
              <Trophy className="w-4 h-4" />
              <span>{winners.length} winners</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
