import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { X, Instagram, Trophy, Download, Copy, CheckCircle, Smartphone, Monitor } from "lucide-react";

const SAINT_FRANCIS_FOOTBALL_IMAGE = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68c864add4a5eaf172913380/82efad38b_SFScoreprediciontinstagram.png";

export default function SharePredictionModal({ game, prediction, onCancel }) {
  const [copied, setCopied] = useState(false);
  const [downloaded, setDownloaded] = useState(false);
  const [imageSaved, setImageSaved] = useState(false);

  // Detect device type
  const userAgent = navigator.userAgent.toLowerCase();
  const isMobile = /android|webos|iphone|ipad|ipod|blackberry|iemobile|opera mini/.test(userAgent);
  const isIOS = /iphone|ipad|ipod/.test(userAgent);
  const isAndroid = /android/.test(userAgent);

  const generateShareText = () => {
    const knightsScore = game.home_team === "Knights" ? prediction.predicted_home_score : prediction.predicted_away_score;
    const opponentScore = game.home_team === "Knights" ? prediction.predicted_away_score : prediction.predicted_home_score;
    const opponent = game.home_team === "Knights" ? game.away_team : game.home_team;
    
    return `Prediction locked for @saintfrancisschools vs ${opponent}. I've got Knights ${knightsScore}–${opponentScore}. Your call?

#WeAreSaintFrancis #KnightNation`;
  };

  const copyShareText = async () => {
    const shareText = generateShareText();
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(shareText);
      } else {
        const textArea = document.createElement('textarea');
        textArea.value = shareText;
        textArea.style.position = 'fixed';
        textArea.style.left = '-9999px';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
      }
      setCopied(true);
      setTimeout(() => setCopied(false), 3000);
    } catch (error) {
      console.error('Error copying text:', error);
      alert('Could not copy text. Please manually copy the caption above.');
    }
  };

  const handleImageSave = async () => {
    if (isMobile) {
      // For mobile, we'll guide them to long-press save
      setImageSaved(true);
      setTimeout(() => setImageSaved(false), 5000);
    } else {
      // Desktop download functionality
      try {
        const response = await fetch(SAINT_FRANCIS_FOOTBALL_IMAGE);
        if (!response.ok) throw new Error('Network response was not ok');
        
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `knights-prediction-${game.away_team.toLowerCase().replace(/\s/g, '-')}.png`;
        document.body.appendChild(link);
        link.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(link);
        setDownloaded(true);
        setTimeout(() => setDownloaded(false), 3000);
      } catch (error) {
        console.error('Error downloading image:', error);
        window.open(SAINT_FRANCIS_FOOTBALL_IMAGE, '_blank');
        alert('Opening image in new tab. Right-click and save the image.');
      }
    }
  };

  const tryWebShare = async () => {
    if (navigator.share) {
      try {
        const response = await fetch(SAINT_FRANCIS_FOOTBALL_IMAGE);
        const blob = await response.blob();
        const file = new File([blob], 'knights-prediction.png', { type: 'image/png' });
        
        await navigator.share({
          title: 'Knights Score Prediction',
          text: generateShareText(),
          files: [file]
        });
        return true;
      } catch (error) {
        console.log('Web Share API failed, falling back to Instagram app');
        return false;
      }
    }
    return false;
  };

  const openInstagramWithOptimization = async () => {
    // Try Web Share API first on mobile
    if (isMobile && await tryWebShare()) {
      return; // Successfully shared via Web Share API
    }

    // Fallback to Instagram app opening
    if (isMobile) {
      if (isIOS) {
        window.location.href = 'instagram://app';
        setTimeout(() => {
          if (document.visibilityState === 'visible') {
            window.open('https://apps.apple.com/app/instagram/id389801252', '_blank');
          }
        }, 2500);
      } else if (isAndroid) {
        try {
          window.location.href = 'intent://instagram.com#Intent;package=com.instagram.android;scheme=https;end';
        } catch (error) {
          window.open('https://play.google.com/store/apps/details?id=com.instagram.android', '_blank');
        }
      } else {
        window.open('https://instagram.com/', '_blank');
      }
    } else {
      window.open('https://instagram.com/', '_blank');
    }
  };

  const knightsScore = game.home_team === "Knights" ? prediction.predicted_home_score : prediction.predicted_away_score;
  const opponentScore = game.home_team === "Knights" ? prediction.predicted_away_score : prediction.predicted_home_score;
  const opponent = game.home_team === "Knights" ? game.away_team : game.home_team;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <CardHeader className="text-center pb-4">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Trophy className="w-8 h-8 text-green-600" />
          </div>
          <CardTitle className="text-green-800">Share Your Prediction! 🏈</CardTitle>
          <div className="text-center text-[#75787b]">
            <p className="text-lg font-bold text-[#041e42] mt-2">
              Knights {knightsScore} - {opponentScore} {opponent}
            </p>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          
          <div className="text-center relative">
            <img 
              src={SAINT_FRANCIS_FOOTBALL_IMAGE} 
              alt="Saint Francis Football Prediction" 
              className="w-full max-w-xs mx-auto rounded-lg shadow-lg"
            />
            {isMobile && (
              <div className="mt-2">
                <p className="text-xs text-blue-600 font-medium">
                  📱 Long-press image above → "Save to Photos" to add to camera roll
                </p>
              </div>
            )}
          </div>

          <div className="bg-gray-50 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-semibold text-[#041e42]">Caption Ready to Copy:</h4>
              {copied && (
                <div className="flex items-center gap-1 text-green-600 text-sm">
                  <CheckCircle className="w-4 h-4" />
                  Copied!
                </div>
              )}
            </div>
            <p className="text-sm text-gray-700 whitespace-pre-line leading-relaxed">
              {generateShareText()}
            </p>
          </div>

          {/* Quick Action Buttons */}
          <div className="grid grid-cols-2 gap-2">
            <Button
              onClick={copyShareText}
              className={`flex items-center justify-center gap-2 transition-colors ${
                copied 
                  ? 'bg-green-600 hover:bg-green-700' 
                  : 'bg-blue-600 hover:bg-blue-700'
              }`}
            >
              {copied ? <CheckCircle className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              {copied ? 'Copied!' : 'Copy Caption'}
            </Button>
            
            <Button
              onClick={handleImageSave}
              variant="outline"
              className={`flex items-center justify-center gap-2 transition-colors ${
                (downloaded || imageSaved) ? 'border-green-500 text-green-600' : ''
              }`}
            >
              {(downloaded || imageSaved) ? <CheckCircle className="w-4 h-4" /> : 
               isMobile ? <Smartphone className="w-4 h-4" /> : <Download className="w-4 h-4" />}
              {(downloaded || imageSaved) ? 'Ready!' : 
               isMobile ? 'Show Guide' : 'Save Image'}
            </Button>
          </div>

          {/* Instagram Button */}
          <Button
            onClick={openInstagramWithOptimization}
            className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 flex items-center justify-center gap-2 text-lg py-3"
          >
            <Instagram className="w-5 h-5" />
            Share
          </Button>

          {/* Instructions */}
          <div className="bg-gradient-to-r from-purple-50 to-pink-50 border border-purple-200 rounded-lg p-4">
            <h4 className="text-sm font-semibold text-[#041e42] mb-2 flex items-center gap-2">
              <Instagram className="w-4 h-4 text-purple-600" />
              {isMobile ? 'Mobile Quick Post:' : 'Quick Post Instructions:'}
            </h4>
            {isMobile ? (
              <ol className="text-xs text-[#75787b] space-y-1">
                <li>1. ✅ Copy caption (done above)</li>
                <li>2. 📷 Long-press image above → "Save to Photos"</li>
                <li>3. 📱 Tap "Share" button to open Instagram</li>
                <li>4. ➕ Create new post in Instagram</li>
                <li>5. 📷 Select the saved image from your photos</li>
                <li>6. 📝 Paste the caption</li>
                <li>7. 🚀 Share your prediction!</li>
              </ol>
            ) : (
              <ol className="text-xs text-[#75787b] space-y-1">
                <li>1. ✅ Copy caption (done above)</li>
                <li>2. 📥 Save image (done above)</li>
                <li>3. 📱 Open Instagram on your phone/tablet</li>
                <li>4. ➕ Create new post in Instagram</li>
                <li>5. 📷 Select the downloaded image</li>
                <li>6. 📝 Paste the caption</li>
                <li>7. 🚀 Share your prediction!</li>
              </ol>
            )}
          </div>

          <Button
            variant="outline"
            onClick={onCancel}
            className="w-full"
          >
            Done
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}