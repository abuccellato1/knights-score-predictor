
import React, { useState, useEffect, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Activity, Instagram, Clock } from "lucide-react";
import { format } from "date-fns";
import { Select, SelectTrigger, SelectContent, SelectItem, SelectValue } from "@/components/ui/select";

import InstagramHandle from "./InstagramHandle";

export default function AllPredictionsFeed({ predictions, games }) {
  const [displayPredictions, setDisplayPredictions] = useState([]);
  // State for filtering by game. "all" means no filter applied.
  const [selectedGameId, setSelectedGameId] = useState("all");
  // State to keep track of the total number of predictions after game filtering, before slicing to 12.
  const [totalFilteredCount, setTotalFilteredCount] = useState(0);

  useEffect(() => {
    let currentPredictions = predictions;

    // Apply game filter if a specific game is selected
    if (selectedGameId !== "all") {
      currentPredictions = predictions.filter(p => p.game_id === selectedGameId);
    }

    // Store the count of predictions after filtering but before slicing
    setTotalFilteredCount(currentPredictions.length);

    // Sort predictions by submitted_at date (most recent first)
    // Then slice to get the top 12
    const recentPredictions = currentPredictions
      .sort((a, b) => new Date(b.submitted_at) - new Date(a.submitted_at))
      .slice(0, 12)
      .map(prediction => {
        // Find the corresponding game for each prediction
        const game = games.find(g => g.id === prediction.game_id);
        // Data integrity: Only include the prediction if a valid game object is found
        return game ? { ...prediction, game } : null;
      })
      .filter(p => p !== null); // Remove any predictions that didn't have a matching game

    setDisplayPredictions(recentPredictions);
  }, [predictions, games, selectedGameId]); // Re-run effect when predictions, games, or selectedGameId change

  // Determine the name of the selected game for display in the badge
  const selectedGameName = useMemo(() => {
    if (selectedGameId === "all") return "All Games";
    const game = games.find(g => g.id === selectedGameId);
    return game ? `${game.home_team} vs ${game.away_team}` : "Unknown Game";
  }, [selectedGameId, games]);


  if (displayPredictions.length === 0 && totalFilteredCount === 0) {
    return (
      <Card className="bg-gradient-to-br from-gray-50 to-blue-50 border-gray-200">
        <CardHeader>
          <CardTitle className="flex flex-col gap-2">
            <div className="flex items-center gap-2 text-[#041e42]">
              <Activity className="w-5 h-5" />
              <span>All Predictions Activity</span>
            </div>
            <div className="flex items-center justify-end"> {/* Changed for responsive - no badge in empty state */}
                <Select onValueChange={setSelectedGameId} defaultValue="all" value={selectedGameId}>
                    <SelectTrigger className="w-[160px] h-8 text-sm">
                        <SelectValue placeholder="Filter by game" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="all">All Games</SelectItem>
                        {games.map(game => (
                            <SelectItem key={game.id} value={game.id}>
                                {game.home_team} vs {game.away_team}
                            </SelectItem>
                        ))}
                    </SelectContent>
                </Select>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center py-8">
          <Activity className="w-12 h-12 text-[#75787b] mx-auto mb-3" />
          <p className="text-[#041e42] font-semibold">
            {selectedGameId === "all" ? "No predictions yet!" : `No predictions for ${selectedGameName}!`}
          </p>
          <p className="text-[#75787b] text-sm">
            {selectedGameId === "all" ? "Recent predictions will appear here." : "Try selecting a different game or adding a prediction."}
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-gradient-to-br from-purple-50 to-blue-50 border-purple-200">
      <CardHeader>
        <CardTitle className="flex flex-col gap-2">
          <div className="flex items-center gap-2 text-[#041e42]">
            <Activity className="w-5 h-5 text-purple-600" />
            <span>All Predictions Activity</span>
          </div>
          <div className="flex items-center justify-between">
            <Badge className="bg-purple-100 text-purple-800">
              {totalFilteredCount > 0
                  ? `${displayPredictions.length}${totalFilteredCount > displayPredictions.length ? ` of ${totalFilteredCount}` : ''} predictions`
                  : 'No predictions'}
            </Badge>
            <div className="flex items-center gap-2">
              {selectedGameId !== "all" && (
                  <Badge variant="secondary" className="text-xs hidden sm:block"> {/* Hidden on extra small screens */}
                      {selectedGameName}
                  </Badge>
              )}
              <Select onValueChange={setSelectedGameId} defaultValue="all" value={selectedGameId}>
                  <SelectTrigger className="w-[160px] h-8 text-sm">
                      <SelectValue placeholder="Filter by game" />
                  </SelectTrigger>
                  <SelectContent>
                      <SelectItem value="all">All Games</SelectItem>
                      {games.map(game => (
                          <SelectItem key={game.id} value={game.id}>
                              {game.home_team} vs {game.away_team}
                          </SelectItem>
                      ))}
                  </SelectContent>
              </Select>
            </div>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3 max-h-96 overflow-y-auto">
          {displayPredictions.map((prediction, index) => (
            <div
              key={prediction.id}
              className={`p-3 rounded-lg border transition-all duration-300 ${
                index < 3
                  ? 'bg-white shadow-md border-purple-300 ring-1 ring-purple-200'
                  : 'bg-white bg-opacity-80 border-gray-200'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 bg-gradient-to-r from-[#041e42] to-[#0a2a5c] rounded-full flex items-center justify-center">
                    <Instagram className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <p className="font-semibold text-[#041e42] text-sm">
                      <InstagramHandle handle={prediction.instagram_handle} />
                    </p>
                  </div>
                </div>
                {index < 3 && (
                  <Badge className="bg-purple-100 text-purple-800 text-xs">
                    New!
                  </Badge>
                )}
              </div>
              
              <div className="space-y-1">
                <p className="text-xs text-[#75787b] flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {/* Data Integrity: Display game details only if prediction.game exists */}
                  {prediction.game ? (
                    <>
                      {prediction.game.home_team} vs {prediction.game.away_team}
                    </>
                  ) : (
                    "Game details missing"
                  )}
                </p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1">
                    <div className="w-6 h-6 bg-[#041e42] text-white rounded flex items-center justify-center text-xs font-bold">
                      {prediction.predicted_home_score}
                    </div>
                    <span className="text-xs text-[#75787b] font-bold">-</span>
                    <div className="w-6 h-6 bg-[#75787b] text-white rounded flex items-center justify-center text-xs font-bold">
                      {prediction.predicted_away_score}
                    </div>
                  </div>
                  <p className="text-xs text-[#75787b]">
                    {format(new Date(prediction.submitted_at), "MMM d, h:mm a")}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        {/* Updated conditional display for the info badge based on filter and total count */}
        {totalFilteredCount > 0 && (
          <div className="text-center mt-4">
            <Badge variant="outline" className="text-xs">
              {displayPredictions.length < totalFilteredCount
                ? `Showing latest ${displayPredictions.length} of ${totalFilteredCount} predictions`
                : `Showing all ${totalFilteredCount} predictions`}
              {selectedGameId !== "all" && ` for ${selectedGameName}`}
            </Badge>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
