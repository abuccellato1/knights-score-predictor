import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Trophy, Users, Calendar, TrendingUp } from "lucide-react";

export default function StatsOverview({ predictions, games }) {
  const totalGames = games.length;
  const completedGames = games.filter(g => g.status === 'completed').length;
  const totalPredictions = predictions.length;
  const totalWinners = predictions.filter(p => p.is_winner).length;
  const avgPredictionsPerGame = totalGames > 0 ? (totalPredictions / totalGames).toFixed(1) : 0;

  // Get popular scores
  const homeScoreCounts = {};
  const awayScoreCounts = {};
  
  predictions.forEach(p => {
    homeScoreCounts[p.predicted_home_score] = (homeScoreCounts[p.predicted_home_score] || 0) + 1;
    awayScoreCounts[p.predicted_away_score] = (awayScoreCounts[p.predicted_away_score] || 0) + 1;
  });

  const mostPredictedHomeScore = Object.keys(homeScoreCounts).reduce((a, b) => 
    homeScoreCounts[a] > homeScoreCounts[b] ? a : b, '0'
  );
  const mostPredictedAwayScore = Object.keys(awayScoreCounts).reduce((a, b) => 
    awayScoreCounts[a] > awayScoreCounts[b] ? a : b, '0'
  );

  return (
    <div className="space-y-6">
      {/* Overview Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <Calendar className="w-8 h-8 text-[#041e42] mx-auto mb-2" />
            <p className="text-2xl font-bold text-[#041e42]">{totalGames}</p>
            <p className="text-sm text-[#75787b]">Total Games</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Users className="w-8 h-8 text-blue-600 mx-auto mb-2" />
            <p className="text-2xl font-bold text-blue-600">{totalPredictions}</p>
            <p className="text-sm text-[#75787b]">Predictions</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Trophy className="w-8 h-8 text-green-600 mx-auto mb-2" />
            <p className="text-2xl font-bold text-green-600">{totalWinners}</p>
            <p className="text-sm text-[#75787b]">Winners</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <TrendingUp className="w-8 h-8 text-purple-600 mx-auto mb-2" />
            <p className="text-2xl font-bold text-purple-600">{avgPredictionsPerGame}</p>
            <p className="text-sm text-[#75787b]">Avg per Game</p>
          </CardContent>
        </Card>
      </div>

      {/* Popular Predictions */}
      <Card>
        <CardHeader>
          <CardTitle className="text-[#041e42]">Popular Predictions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="text-center">
              <p className="text-sm text-[#75787b] mb-2">Most Predicted Knights Score</p>
              <div className="w-16 h-16 bg-[#041e42] text-white rounded-lg flex items-center justify-center mx-auto">
                <span className="text-2xl font-bold">{mostPredictedHomeScore}</span>
              </div>
              <p className="text-xs text-[#75787b] mt-1">
                {homeScoreCounts[mostPredictedHomeScore] || 0} predictions
              </p>
            </div>
            <div className="text-center">
              <p className="text-sm text-[#75787b] mb-2">Most Predicted Opponent Score</p>
              <div className="w-16 h-16 bg-[#75787b] text-white rounded-lg flex items-center justify-center mx-auto">
                <span className="text-2xl font-bold">{mostPredictedAwayScore}</span>
              </div>
              <p className="text-xs text-[#75787b] mt-1">
                {awayScoreCounts[mostPredictedAwayScore] || 0} predictions
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Win Rate */}
      {completedGames > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-[#041e42]">Prediction Accuracy</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center">
              <p className="text-4xl font-bold text-green-600">
                {((totalWinners / totalPredictions) * 100).toFixed(1)}%
              </p>
              <p className="text-[#75787b]">Overall accuracy rate</p>
              <p className="text-sm text-[#75787b] mt-2">
                {totalWinners} correct predictions out of {totalPredictions} total
              </p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}