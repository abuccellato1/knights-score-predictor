
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Trophy, Calendar, LogIn, Share, Instagram } from "lucide-react";
import { format, isAfter } from "date-fns";
import SharePredictionModal from "./SharePredictionModal";
import { User } from "@/api/entities";

export default function MyPredictions({ predictions, games, currentUser, onUpdatePrediction }) {
  const [predictionToShare, setPredictionToShare] = useState(null);
  
  const handleLogin = async () => {
    try {
      await User.loginWithRedirect(window.location.href);
    } catch (error) {
      console.error("Login failed", error);
    }
  };

  if (!currentUser) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Trophy className="w-5 h-5" />
            My Predictions
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center py-12">
          <Trophy className="w-12 h-12 text-[#75787b] mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-[#041e42]">Log In to See Your Predictions</h3>
          <p className="text-[#75787b] mb-4">See your prediction history and share your winning picks!</p>
          <Button onClick={handleLogin}>
            <LogIn className="w-4 h-4 mr-2" />
            Log In
          </Button>
        </CardContent>
      </Card>
    );
  }

  const userPredictions = predictions.filter(p => p.user_email === currentUser.email);
  const winCount = userPredictions.filter(p => p.is_winner).length;
  const totalCount = userPredictions.length;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>Your Predictions</CardTitle>
            {totalCount > 0 && (
              <Badge className="bg-[#041e42] text-white">
                {winCount}/{totalCount} Correct
              </Badge>
            )}
          </div>
          <p className="text-sm text-gray-500">{currentUser.email}</p>
        </CardHeader>
        <CardContent>
          {userPredictions.length > 0 ? (
            <div className="space-y-2">
              {/* Header Row */}
              <div className="grid grid-cols-3 gap-4 pb-3 border-b text-sm font-medium text-[#75787b]">
                <div>Game Details</div>
                <div className="text-center">Prediction vs Actual</div>
                <div className="text-center">Actions</div>
              </div>
              
              {/* Prediction Rows */}
              {userPredictions.map((prediction) => {
                const game = games.find(g => g.id === prediction.game_id);
                if (!game) return null;

                const isGameOpen = game.status === 'scheduled' && isAfter(new Date(game.cutoff_time), new Date());

                return (
                  <div
                    key={prediction.id}
                    className={`grid grid-cols-3 gap-4 py-4 border-b border-gray-100 items-center ${
                      prediction.is_winner ? 'bg-green-50' : ''
                    }`}
                  >
                    {/* Column 1: Game Details */}
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <p className="font-semibold text-[#041e42] text-sm">
                          {game.home_team} vs {game.away_team}
                        </p>
                        {prediction.is_winner && (
                          <Badge className="bg-green-100 text-green-800 text-xs">
                            <Trophy className="w-3 h-3 mr-1" />
                            Winner
                          </Badge>
                        )}
                      </div>
                      <p className="text-xs text-[#75787b] flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {format(new Date(game.game_date), "MMM d, yyyy")}
                      </p>
                      <div className="flex gap-1 flex-wrap">
                        <Badge variant="outline" className="text-xs">{game.sport}</Badge>
                        <Badge variant="outline" className="text-xs">{game.gender}</Badge>
                        <Badge variant="outline" className="text-xs">{game.level}</Badge>
                      </div>
                    </div>

                    {/* Column 2: Prediction vs Actual */}
                    <div className="text-center space-y-2">
                      <div className="flex items-center justify-center gap-4">
                        <div>
                          <p className="text-xs text-[#75787b]">Your Prediction</p>
                          <p className="font-bold text-[#041e42]">
                            {prediction.predicted_home_score} - {prediction.predicted_away_score}
                          </p>
                        </div>
                        {game.status === 'completed' && (
                          <>
                            <div className="text-[#75787b]">vs</div>
                            <div>
                              <p className="text-xs text-[#75787b]">Final Score</p>
                              <p className={`font-bold ${prediction.is_winner ? 'text-green-600' : 'text-red-600'}`}>
                                {game.home_score} - {game.away_score}
                              </p>
                            </div>
                          </>
                        )}
                      </div>
                      {game.status !== 'completed' && (
                        <Badge variant="outline" className="text-xs">Pending</Badge>
                      )}
                    </div>

                    {/* Column 3: Actions */}
                    <div className="text-center flex items-center justify-center gap-2">
                      {isGameOpen && (
                        <Button
                          variant="secondary"
                          size="sm"
                          onClick={() => onUpdatePrediction(prediction)}
                          className="flex items-center gap-1"
                        >
                          Update
                        </Button>
                      )}
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setPredictionToShare({ prediction, game })}
                        className="flex items-center gap-1"
                      >
                        <Instagram className="w-3 h-3" />
                        Share
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-8">
              <Trophy className="w-12 h-12 text-[#75787b] mx-auto mb-4" />
              <p className="text-[#75787b]">
                You haven't made any predictions yet.
              </p>
            </div>
          )}
        </CardContent>
      </Card>
      {predictionToShare && (
        <SharePredictionModal
          game={predictionToShare.game}
          prediction={predictionToShare.prediction}
          onCancel={() => setPredictionToShare(null)}
        />
      )}
    </div>
  );
}
