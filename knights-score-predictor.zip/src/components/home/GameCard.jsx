
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { format, isAfter } from "date-fns";
import { Clock, Trophy, Users, Shield } from "lucide-react";

import LivePredictions from "./LivePredictions";

export default function GameCard({ game, onPredict, predictions = [], canPredict, allPredictions = [], onFilterChange, activeFilters, compact = false }) {
  const predictionCount = predictions.length;
  const winnerCount = predictions.filter(p => p.is_winner).length;
  
  const isOpen = canPredict && isAfter(new Date(game.cutoff_time), new Date());

  const FilterBadge = ({ filterType, value, children }) => (
    <Badge 
      variant={activeFilters[filterType] === value ? "default" : "secondary"}
      onClick={() => onFilterChange(filterType, value)}
      className="cursor-pointer transition-colors hover:bg-gray-300"
    >
      {children}
    </Badge>
  );

  return (
    <div className="space-y-4">
      <Card className={`relative overflow-hidden transition-all duration-300 hover:shadow-lg ${
        game.status === 'completed' ? 'border-green-200' : 
        game.status === 'active' ? 'border-blue-200' : 'border-gray-200'
      }`}>
        {/* Status Badge */}
        <div className="absolute top-3 right-3 z-10">
          {game.status === 'completed' && (
            <Badge className="bg-green-100 text-green-800">Final</Badge>
          )}
          {game.status === 'active' && (
            <Badge className="bg-blue-100 text-blue-800">Live</Badge>
          )}
          {isOpen && (
            <Badge className="bg-yellow-100 text-yellow-800 animate-pulse">Open</Badge>
          )}
        </div>

        <CardContent className={compact ? "p-4" : "p-6"}>
          {/* Game Header */}
          <div className="text-center mb-4">
            <p className={`text-[#75787b] mb-2 ${compact ? 'text-xs' : 'text-sm'}`}>
              {format(new Date(game.game_date), "MMM d, yyyy")}
            </p>
            <div className="flex justify-center gap-2 flex-wrap mb-2">
                <FilterBadge filterType="sport" value={game.sport}>
                    <div className="flex items-center gap-1"><Trophy className="w-3 h-3" /> {game.sport}</div>
                </FilterBadge>
                 <FilterBadge filterType="gender" value={game.gender}>
                    <div className="flex items-center gap-1"><Users className="w-3 h-3" /> {game.gender}</div>
                </FilterBadge>
                 <FilterBadge filterType="level" value={game.level}>
                    <div className="flex items-center gap-1"><Shield className="w-3 h-3" /> {game.level}</div>
                </FilterBadge>
            </div>
            <p className={`font-semibold text-[#041e42] ${compact ? 'text-base' : 'text-lg'}`}>
              {format(new Date(game.game_date), "h:mm a")}
            </p>
          </div>

          {/* Scoreboard */}
          <div className={`bg-gradient-to-r from-[#041e42] to-[#0a2a5c] rounded-lg text-white mb-4 ${compact ? 'p-3' : 'p-4'}`}>
            <div className="grid grid-cols-3 items-center text-center">
              {/* Home Team */}
              <div>
                <p className={`opacity-80 ${compact ? 'text-xs' : 'text-sm'}`}>HOME</p>
                <p className={`font-bold ${compact ? 'text-sm' : 'text-lg'}`}>{game.home_team}</p>
                {game.status === 'completed' && (
                  <p className={`font-bold text-yellow-400 ${compact ? 'text-lg' : 'text-2xl'}`}>{game.home_score}</p>
                )}
              </div>
              
              {/* VS or Score */}
              <div className={`font-bold ${compact ? 'text-lg' : 'text-2xl'}`}>
                {game.status === 'completed' ? '-' : 'VS'}
              </div>
              
              {/* Away Team */}
              <div>
                <p className={`opacity-80 ${compact ? 'text-xs' : 'text-sm'}`}>AWAY</p>
                <p className={`font-bold ${compact ? 'text-sm' : 'text-lg'}`}>{game.away_team}</p>
                {game.status === 'completed' && (
                  <p className={`font-bold text-yellow-400 ${compact ? 'text-lg' : 'text-2xl'}`}>{game.away_score}</p>
                )}
              </div>
            </div>
          </div>

          {/* Prediction Stats */}
          <div className={`flex justify-center gap-4 mb-4 text-[#75787b] ${compact ? 'text-xs' : 'text-sm'}`}>
            <div className="flex items-center gap-1">
              <Users className="w-4 h-4" />
              <span>{predictionCount} predictions</span>
            </div>
            {game.status === 'completed' && winnerCount > 0 && (
              <div className="flex items-center gap-1">
                <Trophy className="w-4 h-4" />
                <span>{winnerCount} winners</span>
              </div>
            )}
          </div>

          {/* Action Button */}
          {isOpen && onPredict && (
            <Button
              onClick={onPredict}
              className={`w-full bg-[#041e42] hover:bg-[#0a2a5c] mb-4 ${compact ? 'py-2 text-sm' : ''}`}
            >
              Make Prediction
            </Button>
          )}

          {!isOpen && game.status === 'scheduled' && (
            <div className={`text-center text-[#75787b] mb-4 ${compact ? 'text-xs' : 'text-sm'}`}>
              <Clock className="w-4 h-4 mx-auto mb-1" />
              Predictions closed
            </div>
          )}
        </CardContent>
      </Card>

      {/* Live Predictions Feed - Only show for open games and not compact */}
      {isOpen && !compact && (
        <LivePredictions gameId={game.id} predictions={allPredictions} />
      )}
    </div>
  );
}
