
import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Activity, Instagram } from "lucide-react";
import { format } from "date-fns";

import InstagramHandle from "./InstagramHandle";

export default function LivePredictions({ gameId, predictions, showTitle = true }) {
  const [displayPredictions, setDisplayPredictions] = useState([]);

  // Filter and sort recent predictions for this game
  useEffect(() => {
    const gamePredictions = predictions
      .filter(p => p.game_id === gameId)
      .sort((a, b) => new Date(b.submitted_at) - new Date(a.submitted_at))
      .slice(0, 8); // Show last 8 predictions
    
    setDisplayPredictions(gamePredictions);
  }, [gameId, predictions]);

  if (displayPredictions.length === 0) {
    return (
      <Card className="bg-gradient-to-br from-blue-50 to-purple-50 border-blue-200">
        <CardContent className="p-6 text-center">
          <Activity className="w-12 h-12 text-blue-500 mx-auto mb-3" />
          <p className="text-[#041e42] font-semibold">Be the first to predict!</p>
          <p className="text-[#75787b] text-sm">Your prediction will appear here</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-gradient-to-br from-green-50 to-blue-50 border-green-200">
      {showTitle && (
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-[#041e42]">
            <Activity className="w-5 h-5 text-green-600" />
            Live Predictions
            <Badge className="bg-green-100 text-green-800">
              {displayPredictions.length} submitted
            </Badge>
          </CardTitle>
        </CardHeader>
      )}
      <CardContent className={showTitle ? "" : "pt-4"}>
        <div className="space-y-3 max-h-64 overflow-y-auto">
          {displayPredictions.map((prediction, index) => (
            <div
              key={prediction.id}
              className={`flex items-center justify-between p-3 rounded-lg border transition-all duration-300 ${
                index === 0 
                  ? 'bg-white shadow-md border-green-300 ring-2 ring-green-200' 
                  : 'bg-white bg-opacity-70 border-gray-200'
              }`}
            >
              <div className="flex items-center gap-2 sm:gap-3">
                <div className="w-10 h-10 bg-gradient-to-r from-[#041e42] to-[#0a2a5c] rounded-full hidden sm:flex items-center justify-center">
                  <Instagram className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="font-semibold text-[#041e42] text-sm">
                    <InstagramHandle handle={prediction.instagram_handle} />
                  </p>
                  <p className="text-xs text-[#75787b]">
                    {format(new Date(prediction.submitted_at), "MMM d, h:mm a")}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <div className="flex items-center gap-1">
                  <div className="w-8 h-8 bg-[#041e42] text-white rounded flex items-center justify-center text-sm font-bold">
                    {prediction.predicted_home_score}
                  </div>
                  <span className="text-[#75787b] font-bold">-</span>
                  <div className="w-8 h-8 bg-[#75787b] text-white rounded flex items-center justify-center text-sm font-bold">
                    {prediction.predicted_away_score}
                  </div>
                </div>
                {index === 0 && (
                  <Badge className="bg-green-100 text-green-800 text-xs mt-1">
                    Latest!
                  </Badge>
                )}
              </div>
            </div>
          ))}
        </div>
        
        {displayPredictions.length >= 8 && (
          <div className="text-center mt-3">
            <Badge variant="outline" className="text-xs">
              Showing latest 8 predictions
            </Badge>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
