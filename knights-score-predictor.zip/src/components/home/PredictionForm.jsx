
import React, { useState, useEffect } from "react";
import { Prediction, User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { X, Save } from "lucide-react";
import { format } from "date-fns";
import SharePredictionModal from "./SharePredictionModal";

export default function PredictionForm({ game, onSubmit, onCancel, predictionToEdit }) {
  const [formData, setFormData] = useState({
    first_name: '',
    last_name: '',
    user_email: '',
    instagram_handle: '',
    predicted_home_score: '',
    predicted_away_score: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSharePrompt, setShowSharePrompt] = useState(false);
  const [submittedPrediction, setSubmittedPrediction] = useState(null);
  const [needsInstagramHandle, setNeedsInstagramHandle] = useState(false);
  const [tempInstagramHandle, setTempInstagramHandle] = useState('');
  const [buttonPressed, setButtonPressed] = useState(null); // Track which button was pressed

  useEffect(() => {
    const parseFullName = (fullName) => {
      if (!fullName) return { first_name: '', last_name: '' };
      
      const nameParts = fullName.trim().split(' ');
      const first_name = nameParts[0] || '';
      const last_name = nameParts.slice(1).join(' ') || '';
      
      return { first_name, last_name };
    };

    const autoUpdateUserProfile = async (user) => {
      try {
        // Check if we need to auto-populate name fields from full_name
        if ((!user.first_name || !user.last_name) && user.full_name) {
          const { first_name, last_name } = parseFullName(user.full_name);
          
          const updateData = {};
          if (!user.first_name && first_name) updateData.first_name = first_name;
          if (!user.last_name && last_name) updateData.last_name = last_name;
          
          if (Object.keys(updateData).length > 0) {
            console.log('Auto-updating user profile with parsed name:', updateData);
            await User.updateMyUserData(updateData);
            
            // Return the updated user data
            return { ...user, ...updateData };
          }
        }
        return user;
      } catch (error) {
        console.error('Error auto-updating user profile:', error);
        return user;
      }
    };

    const initializeFormData = async () => {
      if (predictionToEdit) {
        // If editing, populate all relevant fields from the prediction object
        const { first_name, last_name } = parseFullName(predictionToEdit.user_name);
        setFormData({
          first_name: first_name,
          last_name: last_name,
          user_email: predictionToEdit.user_email || '',
          instagram_handle: predictionToEdit.instagram_handle || '',
          predicted_home_score: predictionToEdit.predicted_home_score,
          predicted_away_score: predictionToEdit.predicted_away_score,
        });
        
        // Still fetch user to check for current profile needs (like IG handle update for profile itself)
        try {
          let user = await User.me();
          if (user && (!user.instagram_handle || user.instagram_handle.trim() === '')) {
            setNeedsInstagramHandle(true);
            setTempInstagramHandle(''); // Reset temp handle for new input
          }
        } catch (error) {
          console.log("Error fetching user in edit mode (likely not logged in):", error);
        }

      } else {
        // If not editing, fetch user data to pre-fill for a new prediction
        try {
          let user = await User.me();
          if (user) {
            user = await autoUpdateUserProfile(user); // Auto-update user's name if needed

            if (!user.instagram_handle || user.instagram_handle.trim() === '') {
              setNeedsInstagramHandle(true);
              setTempInstagramHandle('');
            }

            // Use user's actual first_name/last_name if available, otherwise parse from full_name
            const { first_name, last_name } = user.first_name && user.last_name
              ? { first_name: user.first_name, last_name: user.last_name }
              : parseFullName(user.full_name);

            setFormData(prev => ({
              ...prev,
              first_name: first_name || '',
              last_name: last_name || '',
              user_email: user.email || '',
              instagram_handle: user.instagram_handle || ''
            }));
          }
        } catch (error) {
          console.log("User not logged in or error fetching user for new prediction:", error);
        }
      }
    };

    initializeFormData();
  }, [predictionToEdit]); // Re-run when predictionToEdit changes

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleUpdateInstagramHandle = async () => {
    const updatedHandle = tempInstagramHandle.replace('@', '').trim();
    if (!updatedHandle) {
      alert("Please enter your Instagram handle.");
      return;
    }
    
    // Basic validation
    if (updatedHandle.length < 1 || updatedHandle.length > 30) {
      alert("Instagram handle must be between 1 and 30 characters.");
      return;
    }

    // Check for invalid characters (only allow letters, numbers, underscores, dots)
    if (!/^[a-zA-Z0-9._]+$/.test(updatedHandle)) {
      alert("Instagram handle can only contain letters, numbers, underscores, and dots.");
      return;
    }
    
    setIsSubmitting(true);
    try {
      // Get current user
      const user = await User.me();
      console.log("Current user:", user);
      
      // Check for uniqueness in our database
      try {
        const existingUsers = await User.filter({ instagram_handle: updatedHandle });
        console.log("Existing users with handle:", existingUsers);
        
        // Check if any OTHER user has this handle
        const conflictingUser = existingUsers.find(u => u.id !== user.id);
        if (conflictingUser) {
          alert("This Instagram handle is already taken in our system. Please choose another one.");
          setIsSubmitting(false);
          return;
        }
      } catch (filterError) {
        console.log("Filter check failed (this might be ok, e.g., no users found):", filterError);
        // Continue anyway - the filter might fail if no users have that handle yet,
        // or if there's a transient network error. The update attempt below will
        // still catch actual unique constraint violations.
      }

      // Update the user's Instagram handle
      console.log("Updating user with handle:", updatedHandle);
      const updatedUser = await User.updateMyUserData({ instagram_handle: updatedHandle });
      console.log("Updated user:", updatedUser);
      
      // Update form state
      setFormData(prev => ({ ...prev, instagram_handle: updatedHandle }));
      setNeedsInstagramHandle(false);
      setTempInstagramHandle('');
      
      console.log("Instagram handle saved successfully");
      
    } catch (error) {
      console.error("Failed to update Instagram handle:", error);
      
      // More specific error messages
      if (error.message && error.message.includes('unique')) {
        alert("This Instagram handle is already taken. Please choose another one.");
      } else if (error.message && error.message.includes('validation')) {
        alert("Invalid Instagram handle format. Please use only letters, numbers, dots, and underscores.");
      } else {
        alert(`Error saving Instagram handle: ${error.message || 'Unknown error'}. Please try again.`);
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Identify which button was pressed
    const submitterId = e.nativeEvent.submitter?.id;
    setButtonPressed(submitterId);
    console.log("Form submitted via button:", submitterId);
    
    // Clean and validate inputs
    const cleanedData = {
      first_name: formData.first_name.trim(),
      last_name: formData.last_name.trim(),
      user_email: formData.user_email.trim().toLowerCase(),
      instagram_handle: formData.instagram_handle.replace('@', '').trim(),
      predicted_home_score: parseInt(formData.predicted_home_score),
      predicted_away_score: parseInt(formData.predicted_away_score)
    };
    
    // Validate all required fields
    if (!cleanedData.first_name || !cleanedData.last_name || 
        !cleanedData.user_email || !cleanedData.instagram_handle || 
        isNaN(cleanedData.predicted_home_score) || isNaN(cleanedData.predicted_away_score)) {
      alert('Please fill in all required fields with valid data');
      return;
    }

    // Basic email validation
    if (!cleanedData.user_email.includes('@') || !cleanedData.user_email.includes('.')) {
      alert('Please enter a valid email address');
      return;
    }

    setIsSubmitting(true);

    try {
      // Also update the logged-in user's profile with any changes made in the form
      try {
        const currentUser = await User.me();
        const profileUpdates = {};
        
        if (currentUser.first_name !== cleanedData.first_name) profileUpdates.first_name = cleanedData.first_name;
        if (currentUser.last_name !== cleanedData.last_name) profileUpdates.last_name = cleanedData.last_name;
        if (currentUser.instagram_handle !== cleanedData.instagram_handle) profileUpdates.instagram_handle = cleanedData.instagram_handle;
        
        if (Object.keys(profileUpdates).length > 0) {
          await User.updateMyUserData(profileUpdates);
        }
      } catch (profileError) {
        console.log('Could not update user profile, continuing with prediction:', profileError);
      }

      // Check for duplicate predictions for this game, excluding the current prediction if editing
      const [existingByEmail, existingByIg] = await Promise.all([
        Prediction.filter({ game_id: game.id, user_email: cleanedData.user_email }),
        Prediction.filter({ game_id: game.id, instagram_handle: cleanedData.instagram_handle })
      ]);

      const emailIsDuplicate = existingByEmail.length > 0 && (!predictionToEdit || existingByEmail[0].id !== predictionToEdit.id);
      if (emailIsDuplicate) {
        alert('This email has already submitted a prediction for this game.');
        setIsSubmitting(false);
        return;
      }

      const igIsDuplicate = existingByIg.length > 0 && (!predictionToEdit || existingByIg[0].id !== predictionToEdit.id);
      if (igIsDuplicate) {
        alert('This Instagram handle has already submitted a prediction for this game.');
        setIsSubmitting(false);
        return;
      }

      const predictionData = {
        game_id: game.id,
        user_name: `${cleanedData.first_name} ${cleanedData.last_name}`,
        user_email: cleanedData.user_email,
        instagram_handle: cleanedData.instagram_handle,
        predicted_home_score: cleanedData.predicted_home_score,
        predicted_away_score: cleanedData.predicted_away_score,
        submitted_at: new Date().toISOString()
      };

      let finalPrediction;
      const isUpdate = predictionToEdit !== null;
      
      if (isUpdate) {
        console.log("UPDATING prediction:", predictionToEdit.id, predictionData);
        finalPrediction = await Prediction.update(predictionToEdit.id, predictionData);
        console.log("✅ Prediction UPDATED successfully:", finalPrediction);
      } else {
        console.log("CREATING new prediction:", predictionData);
        finalPrediction = await Prediction.create(predictionData);
        console.log("✅ Prediction CREATED successfully:", finalPrediction);
      }
      
      // Call onSubmit to update parent state
      onSubmit(finalPrediction);
      
      // 🚨 CRITICAL: Always show sharing instructions after successful submission (both new AND update)
      console.log("🎯 TRIGGERING SHARE MODAL for", isUpdate ? "UPDATE" : "NEW", "prediction:", finalPrediction);
      console.log("Button pressed was:", submitterId);
      
      setSubmittedPrediction(finalPrediction);
      setShowSharePrompt(true);
      
      // Additional debug info
      console.log("showSharePrompt set to:", true);
      console.log("submittedPrediction set to:", finalPrediction);
      
    } catch (error) {
      console.error('❌ Error submitting prediction:', error);
      alert(`Error submitting prediction: ${error.message || 'Please try again.'}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (needsInstagramHandle) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
        <Card className="w-full max-w-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-[#041e42]">
              <X className="w-5 h-5" />
              Add Your Instagram Handle
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <p className="text-[#75787b]">
              Please add your Instagram handle to continue. This is used for sharing and doesn't need to be a real Instagram account - just a unique name for you.
            </p>
            <div>
              <Label htmlFor="temp_instagram_handle">Instagram Handle *</Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-[#75787b]">@</span>
                <Input
                  id="temp_instagram_handle"
                  value={tempInstagramHandle}
                  onChange={(e) => setTempInstagramHandle(e.target.value.replace('@', ''))}
                  required
                  placeholder="yourusername"
                  className="pl-8"
                />
              </div>
              <p className="text-xs text-[#75787b] mt-1">
                This can be any unique name - it doesn't have to be a real Instagram account
              </p>
            </div>
            <div className="flex justify-end gap-3">
              <Button variant="outline" onClick={onCancel} disabled={isSubmitting}>
                Cancel
              </Button>
              <Button onClick={handleUpdateInstagramHandle} disabled={isSubmitting || !tempInstagramHandle.trim()}>
                {isSubmitting ? 'Saving...' : 'Save and Continue'}
                <Save className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Show sharing instructions immediately after successful submission
  if (showSharePrompt && submittedPrediction) {
    console.log("🎉 RENDERING SharePredictionModal with:", { 
      game: game.home_team + " vs " + game.away_team, 
      prediction: submittedPrediction.predicted_home_score + "-" + submittedPrediction.predicted_away_score,
      buttonPressed: buttonPressed 
    });
    return (
      <SharePredictionModal
        game={game}
        prediction={submittedPrediction}
        onCancel={() => {
          console.log("Share modal cancelled, closing prediction flow");
          setShowSharePrompt(false);
          setSubmittedPrediction(null);
          setButtonPressed(null);
          onCancel(); // This closes the entire prediction flow
        }}
      />
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-[#041e42]">
            {predictionToEdit ? 'Edit Your Prediction' : 'Make Your Prediction'}
          </CardTitle>
          <Button variant="ghost" size="icon" onClick={onCancel}>
            <X className="w-4 h-4" />
          </Button>
        </CardHeader>

        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Game Info */}
            <div className="bg-gradient-to-r from-[#041e42] to-[#0a2a5c] rounded-lg p-4 text-white text-center mb-6">
              <p className="text-sm opacity-80 mb-2">
                {format(new Date(game.game_date), "MMM d, yyyy 'at' h:mm a")}
              </p>
              <p className="text-xl font-bold">{game.home_team} vs {game.away_team}</p>
              <p className="text-sm opacity-80 mt-2">
                Predictions close: {format(new Date(game.cutoff_time), "MMM d 'at' h:mm a")}
              </p>
            </div>

            {/* User Info */}
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="first_name">First Name *</Label>
                <Input
                  id="first_name"
                  value={formData.first_name}
                  onChange={(e) => handleInputChange('first_name', e.target.value)}
                  required
                  placeholder="Enter your first name"
                />
              </div>
              <div>
                <Label htmlFor="last_name">Last Name *</Label>
                <Input
                  id="last_name"
                  value={formData.last_name}
                  onChange={(e) => handleInputChange('last_name', e.target.value)}
                  required
                  placeholder="Enter your last name"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="user_email">Email Address *</Label>
              <Input
                id="user_email"
                type="email"
                value={formData.user_email}
                onChange={(e) => handleInputChange('user_email', e.target.value)}
                required
                placeholder="Enter your email"
              />
            </div>

            <div>
              <Label htmlFor="instagram_handle">Instagram Handle *</Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-[#75787b]">@</span>
                <Input
                  id="instagram_handle"
                  value={formData.instagram_handle}
                  onChange={(e) => handleInputChange('instagram_handle', e.target.value.replace('@', ''))}
                  required
                  placeholder="yourusername"
                  className="pl-8"
                />
              </div>
              <p className="text-xs text-[#75787b] mt-1">
                Can be any unique name - it doesn't need to be a real Instagram account
              </p>
            </div>

            {/* Score Prediction */}
            <div>
              <Label className="text-lg font-semibold">Score Prediction</Label>
              <div className="bg-gray-900 rounded-lg p-6 mt-2">
                <div className="grid grid-cols-3 items-center text-center text-white">
                  {/* Home Team */}
                  <div>
                    <p className="text-sm opacity-80 mb-2">HOME</p>
                    <p className="font-bold text-lg mb-3">{game.home_team}</p>
                    <Input
                      type="number"
                      min="0"
                      max="99"
                      value={formData.predicted_home_score}
                      onChange={(e) => handleInputChange('predicted_home_score', e.target.value)}
                      required
                      className="w-16 h-16 text-2xl font-bold text-center mx-auto bg-yellow-400 text-black border-none"
                      placeholder="0"
                    />
                  </div>
                  
                  {/* VS */}
                  <div className="text-2xl font-bold">-</div>
                  
                  {/* Away Team */}
                  <div>
                    <p className="text-sm opacity-80 mb-2">AWAY</p>
                    <p className="font-bold text-lg mb-3">{game.away_team}</p>
                    <Input
                      type="number"
                      min="0"
                      max="99"
                      value={formData.predicted_away_score}
                      onChange={(e) => handleInputChange('predicted_away_score', e.target.value)}
                      required
                      className="w-16 h-16 text-2xl font-bold text-center mx-auto bg-yellow-400 text-black border-none"
                      placeholder="0"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Submit Button */}
            <Button
              id={predictionToEdit ? "update-prediction-btn" : "submit-prediction-btn"}
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-[#041e42] hover:bg-[#0a2a5c] py-3 text-lg"
            >
              {isSubmitting 
                ? (predictionToEdit ? 'Updating...' : 'Submitting...') 
                : (predictionToEdit ? 'Update Prediction' : 'Submit Prediction')}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
