import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { Trophy, Users, Shield, Crown } from "lucide-react";
import InstagramHandle from "./InstagramHandle";

export default function CompletedGameCard({ game, predictions = [], onFilterChange, activeFilters }) {
  const predictionCount = predictions.length;
  const winners = predictions.filter(p => p.is_winner);
  const winnerCount = winners.length;
  
  // Get a random winner to display
  const displayWinner = winners.length > 0 ? winners[Math.floor(Math.random() * winners.length)] : null;

  const FilterBadge = ({ filterType, value, children }) => (
    <Badge 
      variant={activeFilters[filterType] === value ? "default" : "secondary"}
      onClick={() => onFilterChange(filterType, value)}
      className="cursor-pointer transition-colors hover:bg-gray-300"
    >
      {children}
    </Badge>
  );

  return (
    <Card className="border-green-200 bg-green-50">
      <CardContent className="p-4">
        {/* Game Header */}
        <div className="text-center mb-3">
          <div className="flex justify-center gap-2 flex-wrap mb-2">
            <FilterBadge filterType="sport" value={game.sport}>
              <div className="flex items-center gap-1"><Trophy className="w-3 h-3" /> {game.sport}</div>
            </FilterBadge>
            <FilterBadge filterType="gender" value={game.gender}>
              <div className="flex items-center gap-1"><Users className="w-3 h-3" /> {game.gender}</div>
            </FilterBadge>
            <FilterBadge filterType="level" value={game.level}>
              <div className="flex items-center gap-1"><Shield className="w-3 h-3" /> {game.level}</div>
            </FilterBadge>
          </div>
          <p className="text-sm text-[#75787b] mb-1">
            {format(new Date(game.game_date), "MMM d, yyyy")}
          </p>
          <Badge className="bg-green-100 text-green-800 mb-2">Final</Badge>
        </div>

        {/* Scoreboard */}
        <div className="bg-gradient-to-r from-[#041e42] to-[#0a2a5c] rounded-lg p-3 text-white mb-3">
          <div className="grid grid-cols-3 items-center text-center">
            {/* Home Team */}
            <div>
              <p className="text-xs opacity-80">HOME</p>
              <p className="font-bold text-sm">{game.home_team}</p>
              <p className="text-xl font-bold text-yellow-400">{game.home_score}</p>
            </div>
            
            {/* VS */}
            <div className="text-xl font-bold">-</div>
            
            {/* Away Team */}
            <div>
              <p className="text-xs opacity-80">AWAY</p>
              <p className="font-bold text-sm">{game.away_team}</p>
              <p className="text-xl font-bold text-yellow-400">{game.away_score}</p>
            </div>
          </div>
        </div>

        {/* Prediction Stats */}
        <div className="text-center text-sm text-[#75787b] mb-2">
          <div className="flex items-center justify-center gap-1 mb-1">
            <Users className="w-4 h-4" />
            <span>{predictionCount} predictions</span>
          </div>
          {winnerCount > 0 && (
            <div className="flex items-center justify-center gap-1">
              <Trophy className="w-4 h-4 text-green-600" />
              <span className="text-green-600">{winnerCount} winners</span>
            </div>
          )}
        </div>

        {/* Winner Display */}
        {displayWinner && (
          <div className="bg-gradient-to-r from-yellow-100 to-orange-100 rounded-lg p-2 text-center border border-yellow-300">
            <div className="flex items-center justify-center gap-1 mb-1">
              <Crown className="w-4 h-4 text-yellow-600" />
              <span className="text-sm font-semibold text-yellow-800">Winner</span>
            </div>
            <p className="text-sm font-bold text-[#041e42]">
              <InstagramHandle handle={displayWinner.instagram_handle} className="text-[#041e42] hover:text-purple-600" />
            </p>
            <p className="text-xs text-[#75787b]">
              Predicted: {displayWinner.predicted_home_score} - {displayWinner.predicted_away_score}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}