import React from "react";
import { Instagram } from "lucide-react";

export default function InstagramHandle({ handle, className = "" }) {
  const handleClick = (e) => {
    e.preventDefault();
    
    const userAgent = navigator.userAgent.toLowerCase();
    const isMobile = /android|webos|iphone|ipad|ipod|blackberry|iemobile|opera mini/.test(userAgent);
    const isIOS = /iphone|ipad|ipod/.test(userAgent);
    
    if (isMobile) {
      // Try Instagram app deep link first
      const appUrl = `https://instagram.com/_u/${handle}`;
      
      if (isIOS) {
        // iOS - try app link first, fallback to web
        window.location.href = appUrl;
        setTimeout(() => {
          if (document.visibilityState === 'visible') { // Check if not navigated away
            window.open(`https://instagram.com/${handle}`, '_blank');
          }
        }, 2500);
      } else {
        // Android - try app intent first, fallback to web
        const androidIntent = `intent://instagram.com/_u/${handle}#Intent;package=com.instagram.android;scheme=https;end`;
        try {
          window.location.href = androidIntent;
        } catch (error) {
          window.open(`https://instagram.com/${handle}`, '_blank');
        }
      }
    } else {
      // Desktop - open web version
      window.open(`https://instagram.com/${handle}`, '_blank');
    }
  };

  if (!handle) {
    return null;
  }

  return (
    <button
      onClick={handleClick}
      className={`inline-flex items-center gap-1 text-[#041e42] hover:text-purple-600 transition-colors duration-200 font-semibold ${className}`}
      title={`View @${handle} on Instagram`}
    >
      @{handle}
    </button>
  );
}