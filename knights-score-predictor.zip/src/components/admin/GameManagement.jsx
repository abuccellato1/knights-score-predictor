
import React, { useState } from "react";
import { Game, Prediction } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { format } from "date-fns";
import { Edit, Save, Trophy, Clock, CheckCircle2, AlertCircle, Trash2, Shield, Users } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import ManualWinnerSelection from "./ManualWinnerSelection"; // Added import

export default function GameManagement({ games, onGameUpdated, onEditGame, onGameDeleted }) {
  const [editingGame, setEditingGame] = useState(null);
  const [scoreData, setScoreData] = useState({});
  const [showWinnerSelection, setShowWinnerSelection] = useState(null); // Added state

  const handleStartEdit = (game) => {
    setEditingGame(game.id);
    setScoreData({
      home_score: game.home_score || '',
      away_score: game.away_score || ''
    });
  };

  const handleSaveScore = async (game) => {
    try {
      const updatedGame = await Game.update(game.id, {
        home_score: parseInt(scoreData.home_score),
        away_score: parseInt(scoreData.away_score),
      });

      onGameUpdated(updatedGame);
      setEditingGame(null);
    } catch (error) {
      console.error('Error updating game score:', error);
    }
  };

  const handleStatusChange = async (game, newStatus) => {
    try {
      const updatedGameData = { status: newStatus };
      
      // If completing the game, finalize winner statuses for predictions
      if (newStatus === 'completed') {
        const predictions = await Prediction.filter({ game_id: game.id });
        let hasExactWinners = false; // Changed variable name for clarity
        
        // First, try to find predictions with exact scores and update them
        for (const prediction of predictions) {
          const isWinner = 
            prediction.predicted_home_score === game.home_score && // Use game's current scores
            prediction.predicted_away_score === game.away_score;   // Use game's current scores
          
          if (isWinner) {
            hasExactWinners = true;
            if (prediction.is_winner !== isWinner) {
              await Prediction.update(prediction.id, { is_winner: isWinner });
            }
          } else {
            // Ensure non-winning predictions are marked as not winners if they were previously
            if (prediction.is_winner === true) {
              await Prediction.update(prediction.id, { is_winner: false });
            }
          }
        }
        
        // If no exact winners found, and there are predictions, offer manual selection
        if (!hasExactWinners && predictions.length > 0) {
          const updatedGame = await Game.update(game.id, updatedGameData);
          onGameUpdated(updatedGame); // Update the game status
          setShowWinnerSelection(updatedGame); // Open manual winner selection modal
          return; // Exit here to prevent the regular game update below
        }
      }

      // Proceed with regular game status update if conditions above are not met or handled
      const updatedGame = await Game.update(game.id, updatedGameData);
      onGameUpdated(updatedGame);
    } catch (error) {
      console.error('Error updating game status:', error);
    }
  };

  const handleDeleteGame = async (gameId) => {
    try {
      // 1. Find and delete all associated predictions
      const predictionsToDelete = await Prediction.filter({ game_id: gameId });
      for (const prediction of predictionsToDelete) {
        await Prediction.delete(prediction.id);
      }

      // 2. Delete the game itself
      await Game.delete(gameId);
      
      // 3. Notify parent to refresh data
      onGameDeleted();
    } catch (error) {
      console.error("Failed to delete game and associated predictions:", error);
    }
  };

  const handleWinnerSelected = (winner) => {
    console.log('Manual winner selection processed. Winner:', winner);
    // Refresh the game data in the parent component to reflect potential prediction updates
    onGameUpdated(showWinnerSelection);
    setShowWinnerSelection(null); // Close the modal
  };

  const scoreLabels = {
    'Football': 'Score',
    'Basketball': 'Score',
    'Volleyball': 'Sets',
    'Tennis': 'Sets',
  };

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="text-[#041e42]">Game Management</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {games.map((game) => (
              <div key={game.id} className="border rounded-lg p-4">
                {/* Game Header */}
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-[#041e42]">
                      {game.home_team} vs {game.away_team}
                    </h3>
                     <div className="flex items-center gap-2 flex-wrap my-1">
                        <Badge variant="outline" className="text-xs"><Trophy className="w-3 h-3 mr-1"/>{game.sport}</Badge>
                        <Badge variant="outline" className="text-xs"><Users className="w-3 h-3 mr-1"/>{game.gender}</Badge>
                        <Badge variant="outline" className="text-xs"><Shield className="w-3 h-3 mr-1"/>{game.level}</Badge>
                    </div>
                    <p className="text-sm text-[#75787b]">
                      {format(new Date(game.game_date), "MMM d, yyyy 'at' h:mm a")}
                    </p>
                    <p className="text-xs text-[#75787b]">
                      Cutoff: {format(new Date(game.cutoff_time), "MMM d 'at' h:mm a")}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge 
                      className={
                        game.status === 'completed' ? 'bg-green-100 text-green-800' :
                        game.status === 'active' ? 'bg-blue-100 text-blue-800' :
                        'bg-gray-100 text-gray-800'
                      }
                    >
                      {game.status}
                    </Badge>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="destructive" size="icon" disabled={game.status === 'active'}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                          <AlertDialogDescription>
                            This will permanently delete the game against "{game.away_team}" and all associated predictions. This action cannot be undone.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction onClick={() => handleDeleteGame(game.id)}>
                            Yes, Delete Game
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>

                {/* Score Management */}
                {editingGame === game.id ? (
                  <div className="bg-gray-50 rounded-lg p-4">
                    <div className="grid grid-cols-3 items-center gap-4">
                      <div>
                        <Label className="text-sm">{game.home_team} {scoreLabels[game.sport] || 'Score'}</Label>
                        <Input
                          type="number"
                          min="0"
                          value={scoreData.home_score}
                          onChange={(e) => setScoreData(prev => ({
                            ...prev,
                            home_score: e.target.value
                          }))}
                          className="text-center text-lg font-bold"
                        />
                      </div>
                      <div className="text-center text-2xl font-bold text-[#75787b]">-</div>
                      <div>
                        <Label className="text-sm">{game.away_team} {scoreLabels[game.sport] || 'Score'}</Label>
                        <Input
                          type="number"
                          min="0"
                          value={scoreData.away_score}
                          onChange={(e) => setScoreData(prev => ({
                            ...prev,
                            away_score: e.target.value
                          }))}
                          className="text-center text-lg font-bold"
                        />
                      </div>
                    </div>
                    <div className="flex justify-end gap-2 mt-4">
                      <Button
                        variant="outline"
                        onClick={() => setEditingGame(null)}
                      >
                        Cancel
                      </Button>
                      <Button
                        onClick={() => handleSaveScore(game)}
                        className="bg-[#041e42] hover:bg-[#0a2a5c]"
                      >
                        <Save className="w-4 h-4 mr-2" />
                        Save Score
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="bg-gray-50 rounded-lg p-4">
                    <div className="grid grid-cols-3 items-center text-center">
                      <div>
                        <p className="text-sm text-[#75787b]">{game.home_team}</p>
                        <p className="text-2xl font-bold text-[#041e42]">
                          {game.home_score !== null ? game.home_score : '-'}
                        </p>
                      </div>
                      <div className="text-2xl font-bold text-[#75787b]">VS</div>
                      <div>
                        <p className="text-sm text-[#75787b]">{game.away_team}</p>
                        <p className="text-2xl font-bold text-[#041e42]">
                          {game.away_score !== null ? game.away_score : '-'}
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {/* Actions */}
                <div className="flex justify-between items-center mt-4">
                  <div className="flex gap-2">
                    {game.status === 'scheduled' && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleStatusChange(game, 'active')}
                      >
                        <Clock className="w-4 h-4 mr-1" />
                        Start Game
                      </Button>
                    )}
                     {game.status === 'active' && (
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button size="sm" variant="destructive">
                             <CheckCircle2 className="w-4 h-4 mr-1" />
                             Complete Game
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Finalize Game Score?</AlertDialogTitle>
                            <AlertDialogDescription>
                              This will mark the game as complete and calculate winners based on the current score of {game.home_score}-{game.away_score}. 
                              If no one got the exact score, you'll be able to manually select a winner.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={() => handleStatusChange(game, 'completed')}>
                              Yes, Complete Game
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    )}
                  </div>
                  
                  <div className="flex gap-2">
                    {game.status !== 'completed' && (
                      <Button
                        size="sm"
                        onClick={() => handleStartEdit(game)}
                        className="bg-blue-600 hover:bg-blue-700"
                      >
                        <Edit className="w-4 h-4 mr-1" />
                        {game.status === 'active' ? 'Update Live Score' : 'Set Score'}
                      </Button>
                    )}
                    {game.status === 'completed' && (
                       <div className="flex items-center gap-2 text-sm text-green-600">
                          <CheckCircle2 className="w-4 h-4" />
                          <span>Game Completed</span>
                      </div>
                    )}
                     <Button
                        size="sm"
                        variant="outline"
                        onClick={() => onEditGame(game)}
                      >
                        <Edit className="w-4 h-4 mr-1" />
                        Edit Game
                      </Button>
                  </div>
                </div>
              </div>
            ))}

            {games.length === 0 && (
              <div className="text-center py-8">
                <Trophy className="w-16 h-16 text-[#75787b] mx-auto mb-4" />
                <p className="text-[#75787b]">No games scheduled yet. Create your first game!</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Manual Winner Selection Modal */}
      {showWinnerSelection && (
        <ManualWinnerSelection
          game={showWinnerSelection}
          predictions={[]} // Predictions will be loaded inside ManualWinnerSelection
          onClose={() => setShowWinnerSelection(null)}
          onWinnerSelected={handleWinnerSelected}
        />
      )}
    </>
  );
}
