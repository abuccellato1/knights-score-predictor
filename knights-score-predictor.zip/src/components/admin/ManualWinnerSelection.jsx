import React, { useState, useEffect } from "react";
import { Prediction } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Trophy, Crown, CheckCircle, X } from "lucide-react";
import { format } from "date-fns";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function ManualWinnerSelection({ game, onClose, onWinnerSelected }) {
  const [selecting, setSelecting] = useState(false);
  const [predictions, setPredictions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadPredictions = async () => {
      try {
        const gamePredictions = await Prediction.filter({ game_id: game.id });
        setPredictions(gamePredictions);
      } catch (error) {
        console.error("Error loading predictions:", error);
      } finally {
        setLoading(false);
      }
    };
    
    loadPredictions();
  }, [game.id]);

  // Filter predictions to show candidates for manual selection
  const candidates = predictions.filter(prediction => {
    const gotHomeScore = prediction.predicted_home_score === game.home_score;
    const gotAwayScore = prediction.predicted_away_score === game.away_score;
    const gotExactScore = gotHomeScore && gotAwayScore;
    
    // Don't show exact matches (they should already be winners)
    // Show predictions that got at least one score right
    return !gotExactScore && (gotHomeScore || gotAwayScore);
  });

  // Also show predictions that are very close (within 1 point of both scores)
  const closePredictions = predictions.filter(prediction => {
    const homeScoreDiff = Math.abs(prediction.predicted_home_score - game.home_score);
    const awayScoreDiff = Math.abs(prediction.predicted_away_score - game.away_score);
    const gotExactScore = homeScoreDiff === 0 && awayScoreDiff === 0;
    const gotOneExact = homeScoreDiff === 0 || awayScoreDiff === 0;
    
    // Show predictions within 1 point of both scores, but not exact matches or those with one exact
    return !gotExactScore && !gotOneExact && homeScoreDiff <= 1 && awayScoreDiff <= 1;
  });

  const allCandidates = [...candidates, ...closePredictions];

  const handleSelectWinner = async (prediction) => {
    setSelecting(true);
    try {
      await Prediction.update(prediction.id, { is_winner: true });
      onWinnerSelected(prediction);
      onClose();
    } catch (error) {
      console.error("Error selecting manual winner:", error);
      alert("Error selecting winner. Please try again.");
    } finally {
      setSelecting(false);
    }
  };

  const getPredictionType = (prediction) => {
    const gotHomeScore = prediction.predicted_home_score === game.home_score;
    const gotAwayScore = prediction.predicted_away_score === game.away_score;
    
    if (gotHomeScore && gotAwayScore) return "exact";
    if (gotHomeScore) return "home";
    if (gotAwayScore) return "away";
    return "close";
  };

  const getPredictionTypeLabel = (type) => {
    switch (type) {
      case "home": return "Got Knights Score";
      case "away": return "Got Opponent Score";
      case "close": return "Very Close";
      default: return "";
    }
  };

  const getPredictionTypeColor = (type) => {
    switch (type) {
      case "home": return "bg-blue-100 text-blue-800";
      case "away": return "bg-purple-100 text-purple-800";
      case "close": return "bg-yellow-100 text-yellow-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  if (loading) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
        <Card className="w-full max-w-md">
          <CardContent className="p-8 text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#041e42] mx-auto mb-4"></div>
            <p className="text-[#75787b]">Loading predictions...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-[#041e42]">
            <Crown className="w-5 h-5" />
            Manual Winner Selection
          </CardTitle>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Game Summary */}
          <div className="bg-gradient-to-r from-[#041e42] to-[#0a2a5c] rounded-lg p-4 text-white">
            <div className="text-center mb-3">
              <h3 className="font-bold">{game.home_team} vs {game.away_team}</h3>
              <p className="text-sm opacity-80">{format(new Date(game.game_date), "MMM d, yyyy")}</p>
            </div>
            <div className="grid grid-cols-3 items-center text-center">
              <div>
                <p className="text-sm opacity-80">HOME</p>
                <p className="font-bold text-xl">{game.home_team}</p>
                <p className="text-2xl font-bold text-yellow-400">{game.home_score}</p>
              </div>
              <div className="text-2xl font-bold">-</div>
              <div>
                <p className="text-sm opacity-80">AWAY</p>
                <p className="font-bold text-xl">{game.away_team}</p>
                <p className="text-2xl font-bold text-yellow-400">{game.away_score}</p>
              </div>
            </div>
          </div>

          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <h4 className="font-semibold text-yellow-800 mb-2">No Exact Score Matches Found</h4>
            <p className="text-sm text-yellow-700">
              Since no one predicted the exact score, you can manually select a winner from the candidates below. 
              These are predictions that got at least one team's score correct or were very close.
            </p>
          </div>

          {/* Candidate List */}
          {allCandidates.length > 0 ? (
            <div className="space-y-4">
              <h4 className="font-semibold text-[#041e42]">Winner Candidates ({allCandidates.length})</h4>
              {allCandidates.map((prediction) => {
                const predictionType = getPredictionType(prediction);
                return (
                  <div key={prediction.id} className="border rounded-lg p-4 bg-white hover:bg-gray-50 transition-colors">
                    <div className="flex justify-between items-start">
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <h3 className="font-semibold text-[#041e42]">{prediction.user_name}</h3>
                          <Badge className={getPredictionTypeColor(predictionType)}>
                            {getPredictionTypeLabel(predictionType)}
                          </Badge>
                        </div>
                        <p className="text-sm text-[#75787b]">{prediction.user_email}</p>
                        <p className="text-sm text-[#75787b]">@{prediction.instagram_handle}</p>
                        <p className="text-xs text-[#75787b]">
                          Submitted: {format(new Date(prediction.submitted_at), "MMM d 'at' h:mm a")}
                        </p>
                      </div>
                      <div className="text-right space-y-2">
                        <div>
                          <p className="text-sm text-[#75787b]">Their Prediction</p>
                          <p className="text-lg font-bold text-[#041e42]">
                            {prediction.predicted_home_score} - {prediction.predicted_away_score}
                          </p>
                        </div>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button 
                              size="sm" 
                              className="bg-green-600 hover:bg-green-700"
                              disabled={selecting}
                            >
                              <Trophy className="w-4 h-4 mr-1" />
                              Select as Winner
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Confirm Manual Winner Selection</AlertDialogTitle>
                              <AlertDialogDescription>
                                Are you sure you want to select {prediction.user_name} (@{prediction.instagram_handle}) 
                                as the winner for this game? They predicted {prediction.predicted_home_score}-{prediction.predicted_away_score}.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction onClick={() => handleSelectWinner(prediction)}>
                                Yes, Select Winner
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-8">
              <Trophy className="w-16 h-16 text-[#75787b] mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-[#041e42] mb-2">No Suitable Candidates</h3>
              <p className="text-[#75787b]">
                No predictions were close enough to the actual score to warrant manual selection.
              </p>
            </div>
          )}

          <div className="flex justify-end">
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}