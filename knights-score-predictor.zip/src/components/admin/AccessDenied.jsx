import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ShieldAlert, Home, LogIn } from "lucide-react";
import { User } from "@/api/entities";

export default function AccessDenied() {
  const handleLogin = async () => {
    try {
      await User.loginWithRedirect(window.location.origin + createPageUrl("Admin"));
    } catch (error) {
      console.error("Login failed:", error);
      // Fallback to regular login
      try {
        await User.login();
      } catch (fallbackError) {
        console.error("Fallback login also failed:", fallbackError);
      }
    }
  };

  return (
    <div className="flex items-center justify-center min-h-[60vh] bg-gray-50">
      <Card className="w-full max-w-md text-center shadow-lg">
        <CardHeader>
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <ShieldAlert className="w-8 h-8 text-red-600" />
          </div>
          <CardTitle className="text-2xl font-bold text-[#041e42]">Access Denied</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <p className="text-[#75787b]">
            You need administrator access to view this page. Please log in with an authorized account.
          </p>
          <div className="flex flex-col sm:flex-row gap-3">
            <Button
              onClick={handleLogin}
              className="flex-1 bg-[#041e42] hover:bg-[#0a2a5c]"
            >
              <LogIn className="w-4 h-4 mr-2" />
              Login
            </Button>
            <Button asChild variant="outline" className="flex-1">
              <Link to={createPageUrl("Home")}>
                <Home className="w-4 h-4 mr-2" />
                Return to Home
              </Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}