import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { TrendingUp, Users, Trophy, Calendar } from "lucide-react";

export default function PredictionStats({ games, predictions }) {
  // Game stats
  const gameStats = games.map(game => ({
    name: `W${game.week} vs ${game.away_team}`,
    predictions: predictions.filter(p => p.game_id === game.id).length,
    winners: predictions.filter(p => p.game_id === game.id && p.is_winner).length
  }));

  // Popular scores
  const homeScores = {};
  const awayScores = {};
  predictions.forEach(p => {
    homeScores[p.predicted_home_score] = (homeScores[p.predicted_home_score] || 0) + 1;
    awayScores[p.predicted_away_score] = (awayScores[p.predicted_away_score] || 0) + 1;
  });

  const homeScoreData = Object.entries(homeScores)
    .sort(([a], [b]) => parseInt(a) - parseInt(b))
    .map(([score, count]) => ({ score: parseInt(score), count }));

  const awayScoreData = Object.entries(awayScores)
    .sort(([a], [b]) => parseInt(a) - parseInt(b))
    .map(([score, count]) => ({ score: parseInt(score), count }));

  return (
    <div className="space-y-6">
      {/* Overall Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <Calendar className="w-8 h-8 text-[#041e42] mx-auto mb-2" />
            <p className="text-2xl font-bold text-[#041e42]">{games.length}</p>
            <p className="text-sm text-[#75787b]">Games</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Users className="w-8 h-8 text-blue-600 mx-auto mb-2" />
            <p className="text-2xl font-bold text-blue-600">{predictions.length}</p>
            <p className="text-sm text-[#75787b]">Predictions</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Trophy className="w-8 h-8 text-green-600 mx-auto mb-2" />
            <p className="text-2xl font-bold text-green-600">
              {predictions.filter(p => p.is_winner).length}
            </p>
            <p className="text-sm text-[#75787b]">Winners</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <TrendingUp className="w-8 h-8 text-purple-600 mx-auto mb-2" />
            <p className="text-2xl font-bold text-purple-600">
              {games.length > 0 ? (predictions.length / games.length).toFixed(1) : 0}
            </p>
            <p className="text-sm text-[#75787b]">Avg per Game</p>
          </CardContent>
        </Card>
      </div>

      {/* Predictions per Game */}
      <Card>
        <CardHeader>
          <CardTitle className="text-[#041e42]">Predictions per Game</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={gameStats}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="predictions" fill="#041e42" />
              <Bar dataKey="winners" fill="#22c55e" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Popular Scores */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-[#041e42]">Knights Score Predictions</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={homeScoreData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="score" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="count" fill="#041e42" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-[#041e42]">Opponent Score Predictions</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={awayScoreData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="score" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="count" fill="#75787b" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}