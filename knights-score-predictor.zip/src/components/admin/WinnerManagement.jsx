
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Trophy, Mail, Instagram, Copy } from "lucide-react";
import { format } from "date-fns";

export default function WinnerManagement({ games, predictions }) {
  const [selectedGame, setSelectedGame] = useState('');
  const [copiedEmails, setCopiedEmails] = useState(false);

  const completedGames = games.filter(g => g.status === 'completed');
  const selectedGameData = completedGames.find(g => g.id === selectedGame);
  const winners = selectedGame ? 
    predictions.filter(p => p.game_id === selectedGame && p.is_winner) : [];

  const copyWinnerEmails = () => {
    const emails = winners.map(w => w.user_email).join(', ');
    navigator.clipboard.writeText(emails);
    setCopiedEmails(true);
    setTimeout(() => setCopiedEmails(false), 2000);
  };

  const copyInstagramHandles = () => {
    const handles = winners.map(w => `@${w.instagram_handle}`).join(' ');
    navigator.clipboard.writeText(handles);
  };

  return (
    <div className="space-y-6">
      {/* Game Selection */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-[#041e42]">
            <Trophy className="w-5 h-5" />
            Winner Management
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-[#75787b] mb-2 block">
                Select Completed Game
              </label>
              <Select value={selectedGame} onValueChange={setSelectedGame}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a game to view winners..." />
                </SelectTrigger>
                <SelectContent>
                  {completedGames.map((game) => (
                    <SelectItem key={game.id} value={game.id}>
                      {game.home_team} vs {game.away_team} 
                      ({format(new Date(game.game_date), "MMM d")})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {selectedGameData && (
              <div className="bg-gradient-to-r from-[#041e42] to-[#0a2a5c] rounded-lg p-4 text-white">
                <div className="grid grid-cols-3 items-center text-center">
                  <div>
                    <p className="text-sm opacity-80">HOME</p>
                    <p className="font-bold text-lg">{selectedGameData.home_team}</p>
                    <p className="text-2xl font-bold text-yellow-400">{selectedGameData.home_score}</p>
                  </div>
                  <div className="text-2xl font-bold">-</div>
                  <div>
                    <p className="text-sm opacity-80">AWAY</p>
                    <p className="font-bold text-lg">{selectedGameData.away_team}</p>
                    <p className="text-2xl font-bold text-yellow-400">{selectedGameData.away_score}</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Winners List */}
      {selectedGame && (
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle className="flex items-center gap-2">
                <Trophy className="w-5 h-5 text-yellow-600" />
                Winners ({winners.length})
              </CardTitle>
              {winners.length > 0 && (
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={copyWinnerEmails}
                    className="flex items-center gap-2"
                  >
                    <Mail className="w-4 h-4" />
                    {copiedEmails ? 'Copied!' : 'Copy Emails'}
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={copyInstagramHandles}
                    className="flex items-center gap-2"
                  >
                    <Instagram className="w-4 h-4" />
                    Copy IG Handles
                  </Button>
                </div>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {winners.length > 0 ? (
              <div className="space-y-4">
                {winners.map((winner) => (
                  <div 
                    key={winner.id}
                    className="border border-green-200 bg-green-50 rounded-lg p-4"
                  >
                    <div className="flex justify-between items-start">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <h3 className="font-semibold text-[#041e42]">{winner.user_name}</h3>
                          <Badge className="bg-green-100 text-green-800">
                            <Trophy className="w-3 h-3 mr-1" />
                            Winner
                          </Badge>
                        </div>
                        <p className="text-sm text-[#75787b] flex items-center gap-1">
                          <Mail className="w-4 h-4" />
                          {winner.user_email}
                        </p>
                        <p className="text-sm text-[#75787b] flex items-center gap-1">
                          <Instagram className="w-4 h-4" />
                          @{winner.instagram_handle}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-[#75787b]">Correct Prediction</p>
                        <p className="text-lg font-bold text-[#041e42]">
                          {winner.predicted_home_score} - {winner.predicted_away_score}
                        </p>
                        <p className="text-xs text-[#75787b]">
                          {format(new Date(winner.submitted_at), "MMM d 'at' h:mm a")}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}

                {/* Contact Template */}
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mt-6">
                  <h4 className="font-semibold text-[#041e42] mb-2">Winner Message Template</h4>
                  <p className="text-sm text-[#75787b] italic">
                    "🏆 Congratulations! You correctly predicted the Knights vs {selectedGameData?.away_team} score! 
                    Thanks for participating in our Score Predictor challenge. Stay tuned for more games! #KnightsScorePredictor"
                  </p>
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <Trophy className="w-16 h-16 text-[#75787b] mx-auto mb-4" />
                <p className="text-[#75787b]">
                  {selectedGame ? 'No winners for this game.' : 'Select a game to view winners.'}
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
