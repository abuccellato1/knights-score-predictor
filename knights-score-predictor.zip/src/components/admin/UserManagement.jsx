
import React, { useState, useEffect } from "react";
import { User, Prediction } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { UserCog, ShieldCheck, User as UserIcon, Edit, Save, X, Trash2, Search } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

const ROOT_ADMIN_EMAIL = "abuccellato@sfschools.net";

const UserEditor = ({ user, onSave, onCancel }) => {
  const [formData, setFormData] = useState({
    first_name: user.first_name || '',
    last_name: user.last_name || '',
    instagram_handle: user.instagram_handle || ''
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    await onSave(user.id, formData);
  };

  return (
    <form onSubmit={handleSubmit} className="bg-gray-50 p-4 rounded-lg mt-4 space-y-4">
      <div className="grid md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="first_name">First Name</Label>
          <Input 
            id="first_name" 
            value={formData.first_name} 
            onChange={(e) => setFormData({...formData, first_name: e.target.value})} 
          />
        </div>
        <div>
          <Label htmlFor="last_name">Last Name</Label>
          <Input 
            id="last_name" 
            value={formData.last_name} 
            onChange={(e) => setFormData({...formData, last_name: e.target.value})} 
          />
        </div>
      </div>
      <div>
        <Label htmlFor="instagram_handle">Instagram Handle</Label>
        <Input 
          id="instagram_handle" 
          value={formData.instagram_handle} 
          onChange={(e) => setFormData({...formData, instagram_handle: e.target.value.replace('@','')})}
        />
      </div>
      <div className="flex justify-end gap-2">
        <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>
        <Button type="submit">Save Changes</Button>
      </div>
    </form>
  );
};


export default function UserManagement({ currentUser }) {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingUserId, setEditingUserId] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');

  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    setLoading(true);
    try {
      const allUsers = await User.list();
      console.log("Loaded users:", allUsers); // Debug log to see what we're getting
      setUsers(allUsers);
    } catch (error) {
      console.error("Failed to load users:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleRoleChange = async (userId, newRole) => {
    try {
      await User.update(userId, { role: newRole });
      loadUsers();
    } catch (error) {
      console.error("Failed to update user role:", error);
    }
  };

  const handleUpdateUser = async (userId, data) => {
    try {
      const updatedHandle = data.instagram_handle ? data.instagram_handle.replace('@', '').trim() : '';

      // Check for uniqueness before saving
      if (updatedHandle) {
        const existingUsers = await User.filter({ instagram_handle: updatedHandle });
        if (existingUsers.length > 0 && existingUsers.some(u => u.id !== userId)) {
          alert("This Instagram handle is already taken. Please choose another one.");
          return;
        }
      }

      await User.update(userId, {
          ...data,
          instagram_handle: updatedHandle
      });
      setEditingUserId(null);
      loadUsers();
    } catch (error) {
       console.error("Failed to update user:", error);
       alert("An error occurred while updating the user.");
    }
  };

  const handleDeleteUser = async (userId) => {
    try {
      // 1. Find and delete all predictions by this user
      const userToDelete = users.find(u => u.id === userId);
      if (userToDelete && userToDelete.email) {
        const userPredictions = await Prediction.filter({ user_email: userToDelete.email });
        for (const prediction of userPredictions) {
          await Prediction.delete(prediction.id);
        }
      }

      // 2. Delete the user
      await User.delete(userId);
      
      // 3. Refresh the user list
      loadUsers();
    } catch (error) {
      console.error("Failed to delete user:", error);
      alert("An error occurred while deleting the user. Please try again.");
    }
  };

  const filteredUsers = users.filter(user => {
    const fullName = `${user.first_name || ''} ${user.last_name || ''}`.trim();
    const matchesSearchTerm =
      (fullName && fullName.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (user.email && user.email.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (user.instagram_handle && user.instagram_handle.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesRoleFilter =
      roleFilter === 'all' || user.role === roleFilter;

    return matchesSearchTerm && matchesRoleFilter;
  });
  
  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <UserCog className="w-5 h-5" />
            User Management
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#041e42] mx-auto mb-4"></div>
          <p className="text-[#75787b]">Loading users...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <UserCog className="w-5 h-5" />
          User Management
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative flex-grow">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              type="text"
              placeholder="Search by name, email, or Instagram handle..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9"
            />
          </div>
          <Select value={roleFilter} onValueChange={setRoleFilter}>
            <SelectTrigger className="w-[180px] sm:w-[150px]">
              <SelectValue placeholder="Filter by Role" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Roles</SelectItem>
              <SelectItem value="admin">Admin</SelectItem>
              <SelectItem value="user">User</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-4">
          {filteredUsers.length === 0 && !loading ? (
            <p className="text-center text-gray-500 py-4">No users found matching your criteria.</p>
          ) : (
            filteredUsers.map((user) => {
              const isRootAdmin = user.email === ROOT_ADMIN_EMAIL;
              const isCurrentUser = user.id === currentUser.id;
              const fullName = `${user.first_name || ''} ${user.last_name || ''}`.trim() || 'No Name';
              
              return (
                <div key={user.id} className="border rounded-lg p-4">
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold text-[#041e42]">{fullName}</h3>
                        {user.role === 'admin' ? (
                          <Badge className="bg-[#041e42] text-white"><ShieldCheck className="w-3 h-3 mr-1" />Admin</Badge>
                        ) : (
                           <Badge variant="secondary"><UserIcon className="w-3 h-3 mr-1" />User</Badge>
                        )}
                      </div>
                      <p className="text-sm text-[#75787b]">{user.email}</p>
                      <p className="text-sm text-[#75787b]">
                        Instagram: {user.instagram_handle ? `@${user.instagram_handle}` : 'Not set'}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Select
                        value={user.role}
                        onValueChange={(newRole) => handleRoleChange(user.id, newRole)}
                        disabled={isRootAdmin || isCurrentUser}
                      >
                        <SelectTrigger className="w-[120px]">
                          <SelectValue placeholder="Set role" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="admin">Admin</SelectItem>
                          <SelectItem value="user">User</SelectItem>
                        </SelectContent>
                      </Select>
                       <Button 
                          variant="outline" 
                          size="icon" 
                          onClick={() => setEditingUserId(editingUserId === user.id ? null : user.id)}
                          disabled={isRootAdmin}
                        >
                          {editingUserId === user.id ? <X className="w-4 h-4" /> : <Edit className="w-4 h-4" />}
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                             <Button variant="destructive" size="icon" disabled={isRootAdmin || isCurrentUser}>
                                <Trash2 className="w-4 h-4" />
                             </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                              <AlertDialogDescription>
                                This will permanently delete {fullName} and all their predictions. This action cannot be undone.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction onClick={() => handleDeleteUser(user.id)}>
                                Yes, Delete User
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                    </div>
                  </div>
                   {editingUserId === user.id && (
                    <UserEditor user={user} onSave={handleUpdateUser} onCancel={() => setEditingUserId(null)} />
                  )}
                </div>
              );
            })
          )}
        </div>
      </CardContent>
    </Card>
  );
}
