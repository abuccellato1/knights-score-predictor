
import React, { useState, useEffect } from "react";
import { Game, Sport, Gender, Level, Opponent } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { Calendar as CalendarIcon, X, ArrowRight, ArrowLeft } from "lucide-react"; // Removed Plus
import { motion } from "framer-motion";

export default function GameScheduler({ gameToEdit, onGameSaved, onCancel }) {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    isHomeGame: true,
    sport: '',
    gender: "",
    level: "",
    home_team: 'Knights',
    away_team: '',
    game_date: '',
    game_time: '',
    cutoff_date: '',
    cutoff_time: '',
    season: new Date().getFullYear().toString()
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [options, setOptions] = useState({ sports: [], genders: [], levels: [], opponents: [] });
  const [newOpponent, setNewOpponent] = useState({ home: '', away: '' });
  const isEditMode = !!gameToEdit;

  useEffect(() => {
    const fetchOptions = async () => {
      try {
        const [sports, genders, levels, opponents] = await Promise.all([
          Sport.list(),
          Gender.list(),
          Level.list(),
          Opponent.list()
        ]);
        setOptions({ sports, genders, levels, opponents });
      } catch (error) {
        console.error("Failed to fetch scheduling options:", error);
      }
    };
    fetchOptions();
  }, []);

  useEffect(() => {
    if (isEditMode && gameToEdit) {
        const gameDate = new Date(gameToEdit.game_date);
        const cutoffDate = new Date(gameToEdit.cutoff_time);
        
        setFormData({
            isHomeGame: gameToEdit.home_team === 'Knights',
            sport: gameToEdit.sport || '',
            gender: gameToEdit.gender || "",
            level: gameToEdit.level || "",
            home_team: gameToEdit.home_team,
            away_team: gameToEdit.away_team,
            game_date: gameDate.toISOString().split('T')[0],
            game_time: gameDate.toTimeString().split(' ')[0].substring(0, 5),
            cutoff_date: cutoffDate.toISOString().split('T')[0],
            cutoff_time: cutoffDate.toTimeString().split(' ')[0].substring(0, 5),
            season: gameToEdit.season,
        });
        setCurrentStep(3); // Skip to details for editing
    } else if (!isEditMode) {
        setFormData({
            isHomeGame: true,
            sport: '',
            gender: '',
            level: '',
            home_team: 'Knights',
            away_team: '',
            game_date: '',
            game_time: '',
            cutoff_date: '',
            cutoff_time: '',
            season: new Date().getFullYear().toString()
        });
        setCurrentStep(1);
    }
  }, [gameToEdit, isEditMode]);

  const handleInputChange = (field, value) => {
    setFormData(prev => {
      const newData = { ...prev, [field]: value };
      
      // Auto-adjust teams based on home/away selection
      if (field === 'isHomeGame') {
        if (value) {
          newData.home_team = 'Knights';
          newData.away_team = '';
        } else {
          newData.away_team = 'Knights';
          newData.home_team = '';
        }
        setNewOpponent({ home: '', away: '' }); // Clear new opponent names on location change
      }
      
      // If a team selection changes, clear the corresponding newOpponent input
      if (field === 'home_team' && value !== 'new_opponent') {
        setNewOpponent(prev => ({ ...prev, home: '' }));
      }
      if (field === 'away_team' && value !== 'new_opponent') {
        setNewOpponent(prev => ({ ...prev, away: '' }));
      }

      return newData;
    });
  };

  const handleNextStep = () => {
    if (currentStep < 3) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      let finalHomeTeam = formData.home_team;
      let finalAwayTeam = formData.away_team;

      // Check and create new home opponent
      if (formData.home_team === 'new_opponent' && newOpponent.home.trim()) {
        finalHomeTeam = newOpponent.home.trim();
        const existing = await Opponent.filter({ name: finalHomeTeam });
        if (existing.length === 0) {
          await Opponent.create({ name: finalHomeTeam });
        }
      }

      // Check and create new away opponent
      if (formData.away_team === 'new_opponent' && newOpponent.away.trim()) {
        finalAwayTeam = newOpponent.away.trim();
        const existing = await Opponent.filter({ name: finalAwayTeam });
        if (existing.length === 0) {
          await Opponent.create({ name: finalAwayTeam });
        }
      }
      
      const gameDateTime = new Date(`${formData.game_date}T${formData.game_time}`);
      const cutoffDateTime = new Date(`${formData.cutoff_date}T${formData.cutoff_time}`);

      const gameData = {
        home_team: finalHomeTeam,
        away_team: finalAwayTeam,
        sport: formData.sport,
        gender: formData.gender,
        level: formData.level,
        game_date: gameDateTime.toISOString(),
        cutoff_time: cutoffDateTime.toISOString(),
        season: formData.season,
        status: gameToEdit ? gameToEdit.status : 'scheduled'
      };

      if (isEditMode) {
        await Game.update(gameToEdit.id, gameData);
      } else {
        await Game.create(gameData);
      }
      onGameSaved();
    } catch (error) {
      console.error('Error saving game:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const canProceedStep1 = formData.sport && formData.gender && formData.level;
  
  const isHomeTeamValid = 
    (formData.home_team && formData.home_team !== 'new_opponent') || 
    (formData.home_team === 'new_opponent' && newOpponent.home.trim() !== '');
  
  const isAwayTeamValid = 
    (formData.away_team && formData.away_team !== 'new_opponent') || 
    (formData.away_team === 'new_opponent' && newOpponent.away.trim() !== '');

  const canProceedStep2 = isHomeTeamValid && isAwayTeamValid;


  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-[#041e42]">
            <CalendarIcon className="w-5 h-5" />
            {isEditMode ? 'Edit Game' : 'Schedule New Game'}
            {!isEditMode && (
              <span className="text-sm font-normal text-[#75787b]">
                Step {currentStep} of 3
              </span>
            )}
          </CardTitle>
          <Button variant="ghost" size="icon" onClick={onCancel}>
            <X className="w-4 h-4" />
          </Button>
        </CardHeader>

        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Step 1: Game Type & Details */}
            {currentStep === 1 && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="space-y-6"
              >
                <div>
                  <h3 className="text-lg font-semibold text-[#041e42] mb-4">Game Details</h3>
                  
                  {/* Sport, Gender, Level */}
                  <div className="grid md:grid-cols-3 gap-4">
                    <div>
                      <Label htmlFor="sport">Sport *</Label>
                      <Select
                        value={formData.sport}
                        onValueChange={(value) => handleInputChange('sport', value)}
                        required
                      >
                        <SelectTrigger id="sport">
                          <SelectValue placeholder="Select a sport" />
                        </SelectTrigger>
                        <SelectContent>
                          {options.sports.map(opt => <SelectItem key={opt.id} value={opt.name}>{opt.name}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="gender">Gender *</Label>
                      <Select
                        value={formData.gender}
                        onValueChange={(value) => handleInputChange('gender', value)}
                        required
                      >
                        <SelectTrigger id="gender">
                          <SelectValue placeholder="Select gender" />
                        </SelectTrigger>
                        <SelectContent>
                          {options.genders.map(opt => <SelectItem key={opt.id} value={opt.name}>{opt.name}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="level">Level / Team *</Label>
                      <Select
                        value={formData.level}
                        onValueChange={(value) => handleInputChange('level', value)}
                        required
                      >
                        <SelectTrigger id="level">
                          <SelectValue placeholder="Select level" />
                        </SelectTrigger>
                        <SelectContent>
                           {options.levels.map(opt => <SelectItem key={opt.id} value={opt.name}>{opt.name}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end">
                  <Button
                    type="button"
                    onClick={handleNextStep}
                    disabled={!canProceedStep1}
                    className="bg-[#041e42] hover:bg-[#0a2a5c]"
                  >
                    Next: Teams <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              </motion.div>
            )}

            {/* Step 2: Home/Away & Teams */}
            {currentStep === 2 && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="space-y-6"
              >
                <div>
                  <h3 className="text-lg font-semibold text-[#041e42] mb-4">Game Location & Teams</h3>
                  
                  {/* Home/Away Selection */}
                  <div className="mb-6">
                    <Label className="text-base font-medium mb-3 block">Game Location</Label>
                    <RadioGroup
                      value={formData.isHomeGame ? "home" : "away"}
                      onValueChange={(value) => handleInputChange('isHomeGame', value === "home")}
                      className="flex gap-8"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="home" id="home" />
                        <Label htmlFor="home" className="font-medium">
                          Home Game (Knights play at home)
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="away" id="away" />
                        <Label htmlFor="away" className="font-medium">
                          Away Game (Knights play away)
                        </Label>
                      </div>
                    </RadioGroup>
                  </div>

                  {/* Team Selection */}
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="home_team">Home Team *</Label>
                      <Select
                        value={formData.home_team}
                        onValueChange={(value) => handleInputChange('home_team', value)}
                        required
                        disabled={formData.isHomeGame} // Home team is Knights if it's a home game
                      >
                        <SelectTrigger id="home_team">
                          <SelectValue placeholder="Select home team" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Knights">Knights</SelectItem> {/* Knights is always an option */}
                          <SelectItem value="new_opponent" className="text-blue-600">
                            + Add New Opponent
                          </SelectItem>
                          {options.opponents
                            .filter(opt => opt.name !== 'Knights') // Exclude Knights from dynamic opponents list here
                            .map(opt => <SelectItem key={opt.id} value={opt.name}>{opt.name}</SelectItem>)}
                        </SelectContent>
                      </Select>
                       {formData.home_team === 'new_opponent' && (
                        <Input
                          placeholder="New Home Team Name"
                          value={newOpponent.home}
                          onChange={(e) => setNewOpponent(prev => ({...prev, home: e.target.value}))}
                          className="mt-2"
                        />
                      )}
                    </div>
                    <div>
                      <Label htmlFor="away_team">Away Team *</Label>
                      <Select
                        value={formData.away_team}
                        onValueChange={(value) => handleInputChange('away_team', value)}
                        required
                        disabled={!formData.isHomeGame} // Away team is Knights if it's an away game
                      >
                        <SelectTrigger id="away_team">
                          <SelectValue placeholder="Select away team" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Knights">Knights</SelectItem> {/* Knights is always an option */}
                           <SelectItem value="new_opponent" className="text-blue-600">
                            + Add New Opponent
                          </SelectItem>
                          {options.opponents
                            .filter(opt => opt.name !== 'Knights') // Exclude Knights from dynamic opponents list here
                            .map(opt => <SelectItem key={opt.id} value={opt.name}>{opt.name}</SelectItem>)}
                        </SelectContent>
                      </Select>
                      {formData.away_team === 'new_opponent' && (
                        <Input
                          placeholder="New Away Team Name"
                          value={newOpponent.away}
                          onChange={(e) => setNewOpponent(prev => ({...prev, away: e.target.value}))}
                          className="mt-2"
                        />
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex justify-between">
                  <Button type="button" variant="outline" onClick={handlePrevStep}>
                    <ArrowLeft className="w-4 h-4 mr-2" /> Back
                  </Button>
                  <Button
                    type="button"
                    onClick={handleNextStep}
                    disabled={!canProceedStep2}
                    className="bg-[#041e42] hover:bg-[#0a2a5c]"
                  >
                    Next: Schedule <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              </motion.div>
            )}

            {/* Step 3: Date, Time & Final Details */}
            {currentStep === 3 && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="space-y-6"
              >
                <div>
                  <h3 className="text-lg font-semibold text-[#041e42] mb-4">Game Schedule</h3>
                  
                  {/* Game Date & Time */}
                  <div className="grid md:grid-cols-2 gap-4 mb-4">
                    <div>
                      <Label htmlFor="game_date">Game Date *</Label>
                      <Input
                        id="game_date"
                        type="date"
                        value={formData.game_date}
                        onChange={(e) => handleInputChange('game_date', e.target.value)}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="game_time">Game Time *</Label>
                      <Input
                        id="game_time"
                        type="time"
                        value={formData.game_time}
                        onChange={(e) => handleInputChange('game_time', e.target.value)}
                        required
                      />
                    </div>
                  </div>

                  {/* Cutoff Date & Time */}
                  <div className="grid md:grid-cols-2 gap-4 mb-4">
                    <div>
                      <Label htmlFor="cutoff_date">Prediction Cutoff Date *</Label>
                      <Input
                        id="cutoff_date"
                        type="date"
                        value={formData.cutoff_date}
                        onChange={(e) => handleInputChange('cutoff_date', e.target.value)}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="cutoff_time">Cutoff Time *</Label>
                      <Input
                        id="cutoff_time"
                        type="time"
                        value={formData.cutoff_time}
                        onChange={(e) => handleInputChange('cutoff_time', e.target.value)}
                        required
                      />
                    </div>
                  </div>

                  {/* Season */}
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="season">Season *</Label>
                      <Input
                        id="season"
                        value={formData.season}
                        onChange={(e) => handleInputChange('season', e.target.value)}
                        required
                        placeholder="e.g., 2024"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex justify-between">
                  {!isEditMode && (
                    <Button type="button" variant="outline" onClick={handlePrevStep}>
                      <ArrowLeft className="w-4 h-4 mr-2" /> Back
                    </Button>
                  )}
                  <Button
                    type="submit"
                    disabled={isSubmitting}
                    className={`${isEditMode ? 'w-full' : ''} bg-[#041e42] hover:bg-[#0a2a5c]`}
                  >
                    {isSubmitting ? (isEditMode ? 'Saving...' : 'Creating...') : (isEditMode ? 'Save Changes' : 'Schedule Game')}
                  </Button>
                </div>
              </motion.div>
            )}
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
