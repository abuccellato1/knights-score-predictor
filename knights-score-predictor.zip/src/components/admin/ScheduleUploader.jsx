
import React, { useState } from "react";
import { Game, Sport, Gender, Level, Opponent } from "@/api/entities";
import { UploadPrivateFile, ExtractDataFromUploadedFile } from "@/api/integrations";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { X, Upload, FileText, Download, AlertCircle, CheckCircle } from "lucide-react";

const GAME_UPLOAD_SCHEMA = {
  type: "object",
  properties: {
    games: {
      type: "array",
      items: {
        type: "object",
        properties: {
          home_team: { type: "string" },
          away_team: { type: "string" },
          game_date: { type: "string" },
          cutoff_time: { type: "string" },
          season: { type: "string" },
          sport: { type: "string" },
          gender: { type: "string" },
          level: { type: "string" },
        },
        required: ["home_team", "away_team", "game_date", "cutoff_time", "season", "sport", "gender", "level"],
      },
    },
  },
  required: ["games"],
};

export default function ScheduleUploader({ onClose, onUploadComplete }) {
  const [file, setFile] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [status, setStatus] = useState({ message: "", type: "" });

  const handleFileChange = (e) => {
    if (e.target.files.length > 0) {
      setFile(e.target.files[0]);
      setStatus({ message: "", type: "" });
    }
  };

  const downloadTemplate = () => {
    const header = "home_team,away_team,game_date,cutoff_time,season,sport,gender,level\n";
    const example = "Knights,Example Team,2024-09-20 19:30,2024-09-20 18:30,2024,Football,Men's,Varsity\n";
    const blob = new Blob([header, example], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", "schedule_template.csv");
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const ensureSettingExists = async (entity, name) => {
    try {
      const existing = await entity.filter({ name });
      if (existing.length === 0) {
        await entity.create({ name });
        console.log(`Created new ${entity.name}: ${name}`);
      }
    } catch (error) {
      console.error(`Error ensuring ${entity.name} exists:`, error);
    }
  };

  const handleUpload = async () => {
    if (!file) {
      setStatus({ message: "Please select a file first.", type: "error" });
      return;
    }

    setIsProcessing(true);
    setStatus({ message: "Uploading file...", type: "info" });

    try {
      // Step 1: Upload the file
      const { file_uri } = await UploadPrivateFile({ file });
      if (!file_uri) throw new Error("File upload failed.");

      setStatus({ message: "Extracting data from file...", type: "info" });

      // Step 2: Extract data from the file
      const extractionResult = await ExtractDataFromUploadedFile({
        file_uri,
        json_schema: GAME_UPLOAD_SCHEMA,
      });

      if (extractionResult.status !== 'success' || !extractionResult.output || !extractionResult.output.games) {
        throw new Error(extractionResult.details || "Could not parse data from CSV. Please check the format.");
      }

      const gamesToCreate = extractionResult.output.games;
      
      if(gamesToCreate.length === 0) {
        throw new Error("No valid game data found in the file.");
      }

      setStatus({ message: "Updating app settings with new data...", type: "info" });

      // Step 3: Ensure all sports, genders, levels, and teams exist in settings
      const uniqueSports = [...new Set(gamesToCreate.map(g => g.sport))];
      const uniqueGenders = [...new Set(gamesToCreate.map(g => g.gender))];
      const uniqueLevels = [...new Set(gamesToCreate.map(g => g.level))];
      const uniqueTeams = [...new Set([
        ...gamesToCreate.map(g => g.home_team),
        ...gamesToCreate.map(g => g.away_team)
      ])];

      // Create missing settings entries
      for (const sport of uniqueSports) {
        await ensureSettingExists(Sport, sport);
      }
      for (const gender of uniqueGenders) {
        await ensureSettingExists(Gender, gender);
      }
      for (const level of uniqueLevels) {
        await ensureSettingExists(Level, level);
      }
      for (const team of uniqueTeams) {
        await ensureSettingExists(Opponent, team);
      }

      setStatus({ message: `Processing ${gamesToCreate.length} games. Saving to database...`, type: "info" });

      // Step 4: Process and create games
      const processedGames = gamesToCreate.map(game => ({
        ...game,
        game_date: new Date(game.game_date).toISOString(),
        cutoff_time: new Date(game.cutoff_time).toISOString(),
        status: 'scheduled'
      }));

      await Game.bulkCreate(processedGames);

      setStatus({ 
        message: `Success! ${gamesToCreate.length} games uploaded and app settings updated with ${uniqueSports.length} sports, ${uniqueGenders.length} genders, ${uniqueLevels.length} levels, and ${uniqueTeams.length} teams.`, 
        type: "success" 
      });
      setTimeout(onUploadComplete, 3000);

    } catch (error) {
      setStatus({ message: error.message || "An unknown error occurred.", type: "error" });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-lg">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-[#041e42]">
            <Upload className="w-5 h-5" />
            Upload Schedule
          </CardTitle>
          <Button variant="ghost" size="icon" onClick={onClose} disabled={isProcessing}>
            <X className="w-4 h-4" />
          </Button>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h4 className="font-semibold text-blue-800 mb-2">Instructions</h4>
            <ol className="list-decimal list-inside text-sm text-blue-700 space-y-1">
              <li>Download the CSV template.</li>
              <li>Fill in the game details. Ensure column headers match exactly.</li>
              <li>`game_date` and `cutoff_time` must be in format: `YYYY-MM-DD HH:MM`.</li>
              <li>New sports, genders, levels, and teams will be automatically added to settings.</li>
              <li>Upload the completed CSV file.</li>
            </ol>
            <Button
              variant="link"
              onClick={downloadTemplate}
              className="p-0 h-auto mt-2 text-blue-800"
            >
              <Download className="w-4 h-4 mr-2" />
              Download Template
            </Button>
          </div>

          <div>
            <Label htmlFor="csv-upload">CSV File</Label>
            <Input
              id="csv-upload"
              type="file"
              accept=".csv"
              onChange={handleFileChange}
              disabled={isProcessing}
            />
          </div>

          {status.message && (
            <div className={`flex items-start gap-3 p-3 rounded-md ${
              status.type === 'error' ? 'bg-red-50 text-red-800' : 
              status.type === 'success' ? 'bg-green-50 text-green-800' : 
              'bg-blue-50 text-blue-800'
            }`}>
              {status.type === 'error' && <AlertCircle className="w-5 h-5 mt-0.5" />}
              {status.type === 'success' && <CheckCircle className="w-5 h-5 mt-0.5" />}
              <p className="text-sm">{status.message}</p>
            </div>
          )}

          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={onClose} disabled={isProcessing}>
              Cancel
            </Button>
            <Button
              onClick={handleUpload}
              disabled={isProcessing || !file}
              className="bg-[#041e42] hover:bg-[#0a2a5c]"
            >
              {isProcessing ? (
                <div className="flex items-center gap-2">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  Processing...
                </div>
              ) : (
                "Upload & Process"
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
