import { base44 } from './base44Client';


export const Game = base44.entities.Game;

export const Prediction = base44.entities.Prediction;

export const Sport = base44.entities.Sport;

export const Gender = base44.entities.Gender;

export const Level = base44.entities.Level;

export const Opponent = base44.entities.Opponent;



// auth sdk:
export const User = base44.auth;