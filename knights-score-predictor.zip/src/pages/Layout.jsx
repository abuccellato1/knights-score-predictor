

import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Trophy, Shield, Settings, Users, LogIn, LogOut, User as UserIcon } from "lucide-react";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";

const SAINT_FRANCIS_LOGO = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68c864add4a5eaf172913380/7d2931957_SaintFrancisKnight.png";

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const isAdminPage = location.pathname.toLowerCase().includes('admin');
  const isAccountPage = location.pathname.toLowerCase().includes('myaccount');
  
  const [currentUser, setCurrentUser] = useState(null);
  const [userLoading, setUserLoading] = useState(true);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const user = await User.me();
        setCurrentUser(user);
      } catch (error) {
        setCurrentUser(null);
      } finally {
        setUserLoading(false);
      }
    };

    fetchUser();
  }, []);

  const handleLogin = async () => {
    try {
      await User.loginWithRedirect(window.location.origin + location.pathname);
    } catch (error) {
      console.error("Login failed:", error);
      try {
        await User.login();
      } catch (fallbackError) {
        console.error("Fallback login also failed:", fallbackError);
      }
    }
  };

  const handleLogout = async () => {
    try {
      await User.logout();
      setCurrentUser(null);
      window.location.reload();
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  const isAdmin = currentUser?.role === 'admin';

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#FAFAF9' }}>
      {/* Header */}
      <header className="bg-gradient-to-r from-[#041e42] to-[#0a2a5c] text-white shadow-lg">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-white rounded-lg p-1 flex items-center justify-center overflow-hidden">
                <img 
                  src={SAINT_FRANCIS_LOGO} 
                  alt="Saint Francis Knights" 
                  className="w-full h-full object-contain"
                />
              </div>
              <div className="hidden sm:block">
                <h1 className="text-xl md:text-2xl font-bold">Knights Score Predictor</h1>
                <p className="text-blue-200 text-xs md:text-sm">Predict. Share. Win.</p>
              </div>
              <div className="sm:hidden">
                <h1 className="text-lg font-bold">Knights Predictor</h1>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              {/* Desktop Navigation */}
              <nav className="hidden lg:flex items-center gap-6">
                {!userLoading && currentUser && ( // Gate Predictions link
                  <Link 
                    to={createPageUrl("Home")} 
                    className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors duration-200 ${
                      !isAdminPage && !isAccountPage ? 'bg-white bg-opacity-20' : 'hover:bg-white hover:bg-opacity-10'
                    }`}
                  >
                    <Trophy className="w-4 h-4" />
                    Predictions
                  </Link>
                )}
                {isAdmin && (
                  <Link 
                    to={createPageUrl("Admin")} 
                    className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors duration-200 ${
                      isAdminPage ? 'bg-white bg-opacity-20' : 'hover:bg-white hover:bg-opacity-10'
                    }`}
                  >
                    <Settings className="w-4 h-4" />
                    Admin
                  </Link>
                )}
              </nav>

              {/* Mobile/Tablet Icon Navigation */}
              <nav className="flex lg:hidden items-center gap-1">
                {!userLoading && currentUser && ( // Gate Predictions link
                  <Link 
                    to={createPageUrl("Home")} 
                    className={`p-3 rounded-lg transition-colors duration-200 ${
                      !isAdminPage && !isAccountPage ? 'bg-white bg-opacity-20' : 'hover:bg-white hover:bg-opacity-10'
                    }`}
                    title="Predictions"
                  >
                    <Trophy className="w-5 h-5" />
                  </Link>
                )}
                {isAdmin && (
                  <Link 
                    to={createPageUrl("Admin")} 
                    className={`p-3 rounded-lg transition-colors duration-200 ${
                      isAdminPage ? 'bg-white bg-opacity-20' : 'hover:bg-white hover:bg-opacity-10'
                    }`}
                    title="Admin Dashboard"
                  >
                    <Settings className="w-5 h-5" />
                  </Link>
                )}
              </nav>

              {/* User Menu */}
              {!userLoading && (
                <div className="flex items-center">
                  {currentUser ? (
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button 
                          variant="ghost" 
                          className="p-3 h-auto text-white hover:bg-white hover:bg-opacity-10 rounded-lg"
                          title={`${currentUser.full_name || 'User'} (${currentUser.role === 'admin' ? 'Admin' : 'User'})`}
                        >
                          <UserIcon className="w-5 h-5" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-56">
                        <div className="px-2 py-1.5">
                          <p className="text-sm font-medium">{currentUser.full_name || 'User'}</p>
                          <p className="text-xs text-gray-500">{currentUser.email}</p>
                        </div>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem asChild>
                          <Link to={createPageUrl("MyAccount")} className="flex items-center gap-2">
                            <UserIcon className="w-4 h-4" />
                            My Account
                          </Link>
                        </DropdownMenuItem>
                        {isAdmin && (
                            <DropdownMenuItem asChild>
                              <Link to={createPageUrl("Admin")} className="flex items-center gap-2">
                                <Settings className="w-4 h-4" />
                                Admin Dashboard
                              </Link>
                            </DropdownMenuItem>
                        )}
                        <DropdownMenuSeparator />
                        <DropdownMenuItem onClick={handleLogout} className="flex items-center gap-2 text-red-600">
                          <LogOut className="w-4 h-4" />
                          Logout
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  ) : (
                    <Button
                      onClick={handleLogin}
                      variant="ghost"
                      className="p-3 h-auto text-white hover:bg-white hover:bg-opacity-10 rounded-lg"
                      title="Login"
                    >
                      <LogIn className="w-5 h-5" />
                    </Button>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="min-h-[calc(100vh-80px)]">
        {children}
      </main>

      <footer className="bg-gradient-to-r from-[#041e42] to-[#0a2a5c] text-white py-6 mt-12">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <p className="text-sm opacity-90">
            Knights Score Predictor | built by{' '}
            <a 
              href="https://www.goodfellastech.com" 
              target="_blank" 
              rel="noopener noreferrer"
              className="font-semibold hover:text-yellow-300 transition-colors duration-200"
            >
              Good Fellas Digital Marketing Agency
            </a>
          </p>
        </div>
      </footer>
    </div>
  );
}

