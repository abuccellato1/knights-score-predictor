import React, { useState, useEffect } from "react";
import { User, Sport, Gender, Level, Opponent } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Trash2, Plus, ArrowLeft } from "lucide-react";
import AccessDenied from "../components/admin/AccessDenied";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

// Reusable component for managing a setting category
const SettingsManager = ({ entity, title, noun, onUpdate }) => {
  const [items, setItems] = useState([]);
  const [newItemName, setNewItemName] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const loadItems = async () => {
      setLoading(true);
      try {
        const data = await entity.list();
        setItems(data);
      } catch (error) {
        console.error(`Error loading ${title}:`, error);
      }
      setLoading(false);
    };
    
    loadItems();
  }, [entity, title]);

  const loadItems = async () => {
    setLoading(true);
    try {
      const data = await entity.list();
      setItems(data);
    } catch (error) {
      console.error(`Error loading ${title}:`, error);
    }
    setLoading(false);
  };

  const handleAddItem = async (e) => {
    e.preventDefault();
    if (!newItemName.trim()) return;

    try {
      await entity.create({ name: newItemName.trim() });
      setNewItemName("");
      loadItems();
      if (onUpdate) onUpdate();
    } catch (error) {
      console.error(`Error adding ${noun}:`, error);
    }
  };

  const handleDeleteItem = async (id) => {
    try {
      await entity.delete(id);
      loadItems();
      if (onUpdate) onUpdate();
    } catch (error) {
      console.error(`Error deleting ${noun}:`, error);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleAddItem} className="flex gap-2 mb-4">
          <Input
            value={newItemName}
            onChange={(e) => setNewItemName(e.target.value)}
            placeholder={`Add new ${noun}...`}
          />
          <Button type="submit" size="icon">
            <Plus className="w-4 h-4" />
          </Button>
        </form>
        <div className="space-y-2">
          {loading ? (
            <p className="text-sm text-gray-500">Loading...</p>
          ) : (
            items.map((item) => (
              <div
                key={item.id}
                className="flex items-center justify-between rounded-md border p-3"
              >
                <span>{item.name}</span>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleDeleteItem(item.id)}
                >
                  <Trash2 className="w-4 h-4 text-red-500" />
                </Button>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default function AppSettings() {
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkAdminStatus = async () => {
      try {
        const user = await User.me();
        setIsAdmin(user.role === 'admin');
      } catch (error) {
        setIsAdmin(false);
      } finally {
        setLoading(false);
      }
    };
    checkAdminStatus();
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#041e42]"></div>
      </div>
    );
  }

  if (!isAdmin) {
    return <AccessDenied />;
  }

  return (
    <div className="max-w-6xl mx-auto p-4">
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-3xl font-bold text-[#041e42]">App Settings</h2>
        <Button asChild variant="outline">
          <Link to={createPageUrl("Admin")} className="flex items-center gap-2">
            <ArrowLeft className="w-4 h-4" />
            Back to Admin
          </Link>
        </Button>
      </div>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-2">
        <SettingsManager entity={Sport} title="Sports" noun="sport" />
        <SettingsManager entity={Gender} title="Genders" noun="gender" />
        <SettingsManager entity={Level} title="Levels / Teams" noun="level" />
        <SettingsManager entity={Opponent} title="Team Names" noun="team" />
      </div>
    </div>
  );
}