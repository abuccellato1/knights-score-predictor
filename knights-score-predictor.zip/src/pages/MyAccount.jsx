
import React, { useState, useEffect } from "react";
import { User, Prediction, Game } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { User as UserIcon, Mail, Instagram, Edit, Save, X, Trophy, Calendar, Trash } from "lucide-react";
import { format } from "date-fns";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";


export default function MyAccount() {
  const [currentUser, setCurrentUser] = useState(null);
  const [predictions, setPredictions] = useState([]);
  const [games, setGames] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editMode, setEditMode] = useState(false);
  const [formData, setFormData] = useState({ 
    first_name: '', 
    last_name: '', 
    instagram_handle: '' 
  });
  const navigate = useNavigate();

  const parseFullName = (fullName) => {
    if (!fullName) return { first_name: '', last_name: '' };
    
    const nameParts = fullName.trim().split(' ');
    const first_name = nameParts[0] || '';
    const last_name = nameParts.slice(1).join(' ') || '';
    
    return { first_name, last_name };
  };

  useEffect(() => {
    const autoUpdateUserProfile = async (user) => {
      try {
        // Check if we need to auto-populate name fields from full_name
        if ((!user.first_name || !user.last_name) && user.full_name) {
          const { first_name, last_name } = parseFullName(user.full_name);
          
          const updateData = {};
          if (!user.first_name && first_name) updateData.first_name = first_name;
          if (!user.last_name && last_name) updateData.last_name = last_name;
          
          if (Object.keys(updateData).length > 0) {
            console.log('Auto-updating user profile with parsed name:', updateData);
            await User.updateMyUserData(updateData);
            
            // Return the updated user data
            return { ...user, ...updateData };
          }
        }
        return user;
      } catch (error) {
        console.error('Error auto-updating user profile:', error);
        return user;
      }
    };

    const loadInitialData = async () => {
      setLoading(true);
      try {
        let user = await User.me();
        
        // Auto-update profile if needed
        user = await autoUpdateUserProfile(user);
        
        setCurrentUser(user);
        
        // Use parsed names if the custom fields are empty but full_name exists
        const { first_name, last_name } = user.first_name && user.last_name 
          ? { first_name: user.first_name, last_name: user.last_name }
          : parseFullName(user.full_name);
        
        setFormData({ 
          first_name: first_name || '', 
          last_name: last_name || '',
          instagram_handle: user.instagram_handle || '' 
        });

        const [userPredictions, allGames] = await Promise.all([
          Prediction.filter({ user_email: user.email }, '-submitted_at'),
          Game.list()
        ]);
        setPredictions(userPredictions);
        setGames(allGames);

      } catch (error) {
        console.error("Error loading account data:", error);
        setCurrentUser(null); // Force login
      } finally {
        setLoading(false);
      }
    };

    loadInitialData();
  }, []);

  const handleUpdate = async (e) => {
    e.preventDefault();
    try {
      const updatedHandle = formData.instagram_handle.replace('@', '').trim();

      // Check for uniqueness before saving
      // Only perform check if the handle is not empty and it has changed from the current user's handle
      if (updatedHandle && updatedHandle !== currentUser.instagram_handle) {
        const existingUsers = await User.filter({ instagram_handle: updatedHandle });
        // Check if any *other* user has this handle
        if (existingUsers.length > 0 && existingUsers.some(u => u.id !== currentUser.id)) {
          alert("This Instagram handle is already taken. Please choose another one.");
          return; // Stop the update process
        }
      }

      const updatedUser = await User.updateMyUserData({
        ...formData,
        instagram_handle: updatedHandle
      });
      setCurrentUser(updatedUser);
      setEditMode(false);
    } catch (error) {
      console.error("Failed to update user data:", error);
      alert("An error occurred while updating your profile. Please try again.");
    }
  };

  const handleDeleteAccount = async () => {
    try {
      await User.deleteMyAccount();
      // On successful deletion, log out and redirect to home
      // Assume User.deleteMyAccount also handles session invalidation on the backend
      alert("Your account has been successfully deleted.");
      navigate(createPageUrl("Home"));
    } catch (error) {
      console.error("Error deleting account:", error);
      alert("An error occurred while deleting your account. Please try again.");
    }
  };

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto p-4 text-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#041e42] mx-auto my-8"></div>
        <p className="text-[#75787b]">Loading your account...</p>
      </div>
    );
  }

  if (!currentUser) {
    return (
      <div className="max-w-4xl mx-auto p-4 text-center">
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Access Denied</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="mb-4">Please log in to view your account page.</p>
            <Button asChild>
              <Link to={createPageUrl("Home")}>Return to Home</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const winCount = predictions.filter(p => p.is_winner).length;
  const totalCount = predictions.length;
  
  // Use parsed names if the custom fields are empty but full_name exists
  const { first_name, last_name } = currentUser.first_name && currentUser.last_name 
    ? { first_name: currentUser.first_name, last_name: currentUser.last_name }
    : parseFullName(currentUser.full_name);
  
  const fullName = `${first_name || ''} ${last_name || ''}`.trim();

  return (
    <div className="max-w-4xl mx-auto p-4 space-y-8">
      <h2 className="text-3xl font-bold text-[#041e42]">My Account</h2>
      
      {/* User Information */}
      <Card>
        <CardHeader className="flex flex-row justify-between items-center">
          <CardTitle className="flex items-center gap-2">
            <UserIcon className="w-5 h-5" />
            Your Information
          </CardTitle>
          {!editMode ? (
            <Button variant="outline" size="sm" onClick={() => setEditMode(true)}>
              <Edit className="w-4 h-4 mr-2" /> Edit
            </Button>
          ) : (
             <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => setEditMode(false)}>
                  <X className="w-4 h-4 mr-2" /> Cancel
                </Button>
                <Button size="sm" onClick={handleUpdate}>
                  <Save className="w-4 h-4 mr-2" /> Save
                </Button>
            </div>
          )}
        </CardHeader>
        <CardContent>
          {!editMode ? (
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <UserIcon className="w-5 h-5 text-[#75787b]" />
                <span className="font-medium">{fullName || currentUser.email}</span>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-[#75787b]" />
                <span>{currentUser.email}</span>
              </div>
              <div className="flex items-center gap-3">
                <Instagram className="w-5 h-5 text-[#75787b]" />
                <span>@{currentUser.instagram_handle || 'Not set'}</span>
              </div>
            </div>
          ) : (
            <form onSubmit={handleUpdate} className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="first_name">First Name</Label>
                  <Input 
                    id="first_name" 
                    value={formData.first_name} 
                    onChange={(e) => setFormData({...formData, first_name: e.target.value})} 
                  />
                </div>
                <div>
                  <Label htmlFor="last_name">Last Name</Label>
                  <Input 
                    id="last_name" 
                    value={formData.last_name} 
                    onChange={(e) => setFormData({...formData, last_name: e.target.value})} 
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="instagram_handle">Instagram Handle</Label>
                <Input 
                  id="instagram_handle" 
                  value={formData.instagram_handle} 
                  onChange={(e) => setFormData({...formData, instagram_handle: e.target.value.replace('@','')})}
                  placeholder="yourusername"
                />
              </div>
            </form>
          )}
        </CardContent>
      </Card>

      {/* Prediction History */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="flex items-center gap-2">
              <Trophy className="w-5 h-5" />
              Prediction History
            </CardTitle>
            <Badge className="bg-[#041e42] text-white">
              {winCount} / {totalCount} Correct
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          {predictions.length > 0 ? (
            <div className="space-y-4">
              {predictions.map(prediction => {
                const game = games.find(g => g.id === prediction.game_id);
                if (!game) return null;

                const isWinner = prediction.is_winner;
                const isCompleted = game.status === 'completed';
                
                return (
                  <div key={prediction.id} className={`border rounded-lg p-4 ${isWinner ? 'border-green-500 bg-green-50' : ''}`}>
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <p className="font-semibold text-[#041e42]">{game.home_team} vs {game.away_team}</p>
                        <p className="text-sm text-[#75787b] flex items-center gap-1">
                          <Calendar className="w-4 h-4" /> {format(new Date(game.game_date), "MMM d, yyyy")}
                        </p>
                      </div>
                      {isWinner && <Badge className="bg-green-100 text-green-800">Winner</Badge>}
                      {!isWinner && isCompleted && <Badge variant="destructive">Incorrect</Badge>}
                      {!isCompleted && <Badge variant="outline">Pending</Badge>}
                    </div>
                    <div className="grid grid-cols-2 gap-4 text-center">
                      <div>
                        <p className="text-sm text-[#75787b]">Your Prediction</p>
                        <p className="font-bold text-lg">{prediction.predicted_home_score} - {prediction.predicted_away_score}</p>
                      </div>
                      {isCompleted ? (
                        <div>
                          <p className="text-sm text-[#75787b]">Final Score</p>
                          <p className={`font-bold text-lg ${isWinner ? 'text-green-600' : 'text-red-600'}`}>{game.home_score} - {game.away_score}</p>
                        </div>
                      ) : (
                        <div>
                          <p className="text-sm text-[#75787b]">Final Score</p>
                          <p className="font-bold text-lg">TBD</p>
                        </div>
                      )}
                    </div>
                  </div>
                )
              })}
            </div>
          ) : (
            <p className="text-center text-[#75787b] py-8">You haven't made any predictions yet.</p>
          )}
        </CardContent>
      </Card>

      {/* Account Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-red-600">
            <Trash className="w-5 h-5" />
            Account Actions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="destructive" className="w-full sm:w-auto">
                <Trash className="w-4 h-4 mr-2" /> Delete Account
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                <AlertDialogDescription>
                  This action cannot be undone. This will permanently delete your account
                  and remove all your data from our servers, including all your predictions.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleDeleteAccount} className="bg-red-600 hover:bg-red-700">
                  Delete My Account
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </CardContent>
      </Card>
    </div>
  );
}
