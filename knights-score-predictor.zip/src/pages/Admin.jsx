
import React, { useState, useEffect } from "react";
import { Game, Prediction, User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, Calendar, Trophy, Users, Mail, UserCog, Trash2, Settings, Upload } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";


import GameScheduler from "../components/admin/GameScheduler";
import GameManagement from "../components/admin/GameManagement";
import WinnerManagement from "../components/admin/WinnerManagement";
import PredictionStats from "../components/admin/PredictionStats";
import UserManagement from "../components/admin/UserManagement";
import AccessDenied from "../components/admin/AccessDenied";
import ScheduleUploader from "../components/admin/ScheduleUploader";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function Admin() {
  const [games, setGames] = useState([]);
  const [predictions, setPredictions] = useState([]);
  const [showScheduler, setShowScheduler] = useState(false);
  const [showUploader, setShowUploader] = useState(false);
  const [editingGame, setEditingGame] = useState(null);
  const [loading, setLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState(null);
  const [authError, setAuthError] = useState(false);

  useEffect(() => {
    const checkUserAndLoadData = async () => {
      setLoading(true);
      try {
        const user = await User.me();
        setCurrentUser(user);
        
        if (user?.role === 'admin') {
          await loadData();
        }
        setAuthError(false);
      } catch (error) {
        console.error("Authentication error:", error);
        setCurrentUser(null);
        setAuthError(true);
      } finally {
        setLoading(false);
      }
    };
    checkUserAndLoadData();
  }, []);

  const loadData = async () => {
    try {
      const [gamesData, predictionsData] = await Promise.all([
        Game.list('-game_date'),
        Prediction.list('-submitted_at')
      ]);
      setGames(gamesData);
      setPredictions(predictionsData);
    } catch (error) {
      console.error('Error loading data:', error);
    }
  };

  const handleOpenScheduler = (game = null) => {
    setEditingGame(game);
    setShowScheduler(true);
  };

  const handleCloseScheduler = () => {
    setEditingGame(null);
    setShowScheduler(false);
  };

  const handleGameSaved = () => {
    handleCloseScheduler();
    loadData();
  };
  
  const handleGameDeleted = () => {
    loadData();
  }

  const handleGameUpdated = (updatedGame) => {
    // This function will now simply trigger a data reload to reflect changes
    // The specific update logic will be handled by GameManagement or GameScheduler
    loadData();
  };

  const handleDeletePrediction = async (predictionId) => {
    try {
      await Prediction.delete(predictionId);
      loadData();
    } catch (error) {
      console.error("Failed to delete prediction", error);
    }
  }

  const totalGames = games.length;
  const completedGames = games.filter(g => g.status === 'completed').length;
  const totalPredictions = predictions.length;
  const totalWinners = predictions.filter(p => p.is_winner).length;

  if (loading) {
    return (
      <div className="max-w-6xl mx-auto p-4">
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#041e42] mx-auto mb-4"></div>
          <p className="text-[#75787b]">Verifying access...</p>
        </div>
      </div>
    );
  }

  if (authError || !currentUser || currentUser.role !== 'admin') {
    return <AccessDenied />;
  }

  return (
    <div className="max-w-6xl mx-auto p-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h2 className="text-3xl font-bold text-[#041e42] mb-2">Admin Dashboard</h2>
          <p className="text-[#75787b]">Manage games, predictions, and winners</p>
        </div>
        <div className="flex gap-2">
          <Button 
            onClick={() => handleOpenScheduler()}
            className="bg-[#041e42] hover:bg-[#0a2a5c] flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            Schedule Game
          </Button>
          <Button
            onClick={() => setShowUploader(true)}
            variant="outline"
            className="flex items-center gap-2"
          >
            <Upload className="w-4 h-4" />
            Upload
          </Button>
          <Button asChild variant="outline">
            <Link to={createPageUrl("AppSettings")} className="flex items-center gap-2">
              <Settings className="w-4 h-4" />
              Settings
            </Link>
          </Button>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <Card>
          <CardContent className="p-4 text-center">
            <Calendar className="w-8 h-8 text-[#041e42] mx-auto mb-2" />
            <p className="text-2xl font-bold text-[#041e42]">{totalGames}</p>
            <p className="text-sm text-[#75787b]">Total Games</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Trophy className="w-8 h-8 text-green-600 mx-auto mb-2" />
            <p className="text-2xl font-bold text-green-600">{completedGames}</p>
            <p className="text-sm text-[#75787b]">Completed</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Users className="w-8 h-8 text-blue-600 mx-auto mb-2" />
            <p className="text-2xl font-bold text-blue-600">{totalPredictions}</p>
            <p className="text-sm text-[#75787b]">Predictions</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Mail className="w-8 h-8 text-yellow-600 mx-auto mb-2" />
            <p className="text-2xl font-bold text-yellow-600">{totalWinners}</p>
            <p className="text-sm text-[#75787b]">Winners</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="games" className="space-y-6">
        <div className="overflow-x-auto">
          <TabsList className="grid w-full grid-cols-5 min-w-[500px] mx-auto">
            <TabsTrigger value="games" className="text-xs sm:text-sm">Games</TabsTrigger>
            <TabsTrigger value="predictions" className="text-xs sm:text-sm">Predictions</TabsTrigger>
            <TabsTrigger value="winners" className="text-xs sm:text-sm">Winners</TabsTrigger>
            <TabsTrigger value="stats" className="text-xs sm:text-sm">Statistics</TabsTrigger>
            <TabsTrigger value="auth" className="flex items-center gap-1 text-xs sm:text-sm">
              <UserCog className="w-4 h-4" /> 
              <span className="hidden sm:inline">Authorization</span>
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="games">
          <GameManagement 
            games={games} 
            onGameUpdated={handleGameUpdated}
            onEditGame={handleOpenScheduler}
            onGameDeleted={handleGameDeleted}
          />
        </TabsContent>

        <TabsContent value="predictions">
          <Card>
            <CardHeader>
              <CardTitle>All Predictions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {predictions.map((prediction) => {
                  const game = games.find(g => g.id === prediction.game_id);
                  return (
                    <div key={prediction.id} className="border rounded-lg p-4 flex justify-between items-start">
                      <div>
                        <div className="flex items-center gap-2 mb-2">
                          <p className="font-semibold">{prediction.user_name}</p>
                          {prediction.is_winner && (
                            <Badge className="bg-green-100 text-green-800">Winner</Badge>
                          )}
                        </div>
                        <p className="text-sm text-[#75787b]">{prediction.user_email}</p>
                        <p className="text-sm text-[#75787b]">@{prediction.instagram_handle}</p>
                        {game && (
                          <div className="text-sm text-[#75787b] mt-1">
                            <p>{game.home_team} vs {game.away_team}</p>
                            <p>Predicted: {prediction.predicted_home_score} - {prediction.predicted_away_score}</p>
                          </div>
                        )}
                      </div>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                           <Button variant="destructive" size="sm">
                              <Trash2 className="w-4 h-4" />
                           </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                            <AlertDialogDescription>
                              This will permanently delete this prediction. This action cannot be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={() => handleDeletePrediction(prediction.id)}>
                              Delete
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  );
                })}
                {predictions.length === 0 && (
                  <p className="text-center text-[#75787b] py-8">No predictions yet</p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="winners">
          <WinnerManagement 
            games={games} 
            predictions={predictions}
          />
        </TabsContent>

        <TabsContent value="stats">
          <PredictionStats 
            games={games} 
            predictions={predictions}
          />
        </TabsContent>

        <TabsContent value="auth">
          <UserManagement currentUser={currentUser} />
        </TabsContent>
      </Tabs>

      {showScheduler && (
        <GameScheduler
          gameToEdit={editingGame}
          onGameSaved={handleGameSaved}
          onCancel={handleCloseScheduler}
        />
      )}

      {showUploader && (
        <ScheduleUploader
          onClose={() => setShowUploader(false)}
          onUploadComplete={() => {
            setShowUploader(false);
            loadData();
          }}
        />
      )}
    </div>
  );
}
