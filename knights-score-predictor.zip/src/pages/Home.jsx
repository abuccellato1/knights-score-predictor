
import React, { useState, useEffect } from "react";
import { Game, Prediction } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar, Clock, Trophy, Users, ArrowRight } from "lucide-react";
import { format, isAfter } from "date-fns";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

import GameCard from "../components/home/GameCard";
import ActiveGameCard from "../components/home/ActiveGameCard";
import PredictionForm from "../components/home/PredictionForm";
import MyPredictions from "../components/home/MyPredictions";
import StatsOverview from "../components/home/StatsOverview";
import AllPredictionsFeed from "../components/home/AllPredictionsFeed";
import LivePredictions from "../components/home/LivePredictions";
import CompletedGameCard from "../components/home/CompletedGameCard";
import { User } from "@/api/entities";

export default function Home() {
  const [games, setGames] = useState([]);
  const [predictions, setPredictions] = useState([]);
  const [selectedGame, setSelectedGame] = useState(null);
  const [editingPrediction, setEditingPrediction] = useState(null); // Add state for editing
  const [showPredictionForm, setShowPredictionForm] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({ sport: null, gender: null, level: null });

  useEffect(() => {
    const loadAllData = async () => {
      setLoading(true);
      try {
        // Fetch user first
        const user = await User.me();
        setCurrentUser(user);
      } catch (error) {
        // Not logged in, which is fine.
        setCurrentUser(null);
      } finally {
        // Fetch game and prediction data
        await loadData();
        setLoading(false);
      }
    };
    
    loadAllData();

    // Set up polling to refresh data every 20 seconds
    const interval = setInterval(() => {
      console.log("Polling for new data...");
      loadData();
    }, 20000); // 20 seconds

    // Clean up interval on component unmount
    return () => clearInterval(interval);
  }, []);

  const loadData = async () => {
    try {
      const [gamesData, predictionsData] = await Promise.all([
        Game.list('-game_date'),
        Prediction.list('-submitted_at')
      ]);
      setGames(gamesData);
      setPredictions(predictionsData);
    } catch (error) {
      console.error('Error loading data:', error);
    }
  };

  const handleLoginRedirect = () => {
    try {
      User.loginWithRedirect(window.location.href);
    } catch (error) {
      console.error("Login redirect failed:", error);
    }
  };

  const handleGameSelect = (game) => {
    if (!currentUser) {
      handleLoginRedirect();
    } else {
      setEditingPrediction(null); // Ensure we're not in edit mode
      setSelectedGame(game);
      setShowPredictionForm(true);
    }
  };

  // New handler for when a user wants to update a prediction
  const handleUpdateSelect = (prediction) => {
    const gameForPrediction = games.find(g => g.id === prediction.game_id);
    if (gameForPrediction) {
      setSelectedGame(gameForPrediction);
      setEditingPrediction(prediction);
      setShowPredictionForm(true);
    } else {
      alert("Could not find the game for this prediction.");
    }
  };

  const handlePredictionSubmitted = () => {
    setPredictions(prev => [...prev]); // Trigger re-render
    setShowPredictionForm(false);
    setSelectedGame(null);
    setEditingPrediction(null); // Clear editing state
    // Refresh data to get latest predictions
    loadData();
  };

  const handleFilterChange = (filterType, value) => {
    setFilters(prev => ({
      ...prev,
      [filterType]: prev[filterType] === value ? null : value, // Toggle filter
    }));
  };

  const filteredGames = games.filter(game => {
    return (
      (!filters.sport || game.sport === filters.sport) &&
      (!filters.gender || game.gender === filters.gender) &&
      (!filters.level || game.level === filters.level)
    );
  });

  const upcomingGames = filteredGames.filter(game => 
    game.status === 'scheduled' && isAfter(new Date(game.cutoff_time), new Date())
  );
  
  const activeGames = filteredGames.filter(game => game.status === 'active');
  const completedGames = filteredGames.filter(game => game.status === 'completed');

  if (loading) {
    return (
      <div className="max-w-6xl mx-auto p-4">
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#041e42] mx-auto mb-4"></div>
          <p className="text-[#75787b]">Loading games...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto p-4">
      {/* Hero Section */}
      <div className="text-center py-8 mb-8">
        <h2 className="text-3xl md:text-4xl font-bold text-[#041e42] mb-4">
          Make Your Predictions
        </h2>
        <p className="text-lg text-[#75787b] max-w-2xl mx-auto">
          Predict the Knights' scores, share your predictions on Instagram, and compete with fellow fans!
        </p>
      </div>

      <Tabs defaultValue="games" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3 max-w-md mx-auto h-12">
          <TabsTrigger value="games" className="flex items-center gap-1 text-xs sm:text-sm">
            <Trophy className="w-4 h-4" />
            <span className="hidden sm:inline">Games</span>
          </TabsTrigger>
          <TabsTrigger value="predictions" className="flex items-center gap-1 text-xs sm:text-sm">
            <Users className="w-4 h-4" />
            <span className="hidden sm:inline">My Predictions</span>
          </TabsTrigger>
          <TabsTrigger value="stats" className="flex items-center gap-1 text-xs sm:text-sm">
            <Calendar className="w-4 h-4" />
            <span className="hidden sm:inline">Stats</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="games" className="space-y-6">
          {/* Active Games - Top Priority */}
          {activeGames.length > 0 && (
            <Card className="border-red-200 bg-red-50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-red-800">
                  <Trophy className="w-5 h-5" />
                  🔴 LIVE GAME
                  <Badge className="bg-red-500 text-white animate-pulse">LIVE</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {activeGames.map((game) => (
                    <ActiveGameCard
                      key={game.id}
                      game={game}
                      predictions={predictions.filter(p => p.game_id === game.id)}
                      allPredictions={predictions}
                      onDataUpdate={loadData}
                      onFilterChange={handleFilterChange}
                      activeFilters={filters}
                    />
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Upcoming Games - Next 3 in Grid */}
          {upcomingGames.length > 0 && (
            <Card className="border-green-200 bg-green-50">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle className="flex items-center gap-2 text-green-800">
                    <Clock className="w-5 h-5" />
                    Upcoming Games
                  </CardTitle>
                  {games.length > 3 && (
                    <Button variant="outline" size="sm" asChild>
                      <Link to={createPageUrl("AllGames")} className="flex items-center gap-1">
                        View All Games
                        <ArrowRight className="w-4 h-4" />
                      </Link>
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Game Grid - Top 3 */}
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {upcomingGames.slice(0, 3).map((game) => (
                    <GameCard
                      key={game.id}
                      game={game}
                      onPredict={() => handleGameSelect(game)}
                      predictions={predictions.filter(p => p.game_id === game.id)}
                      allPredictions={predictions}
                      canPredict={true}
                      onFilterChange={handleFilterChange}
                      activeFilters={filters}
                      compact={true}
                    />
                  ))}
                </div>

                {/* Live Predictions for Upcoming Games */}
                {upcomingGames.length > 0 && (
                  <div>
                    <h4 className="text-lg font-semibold text-green-800 mb-4">Latest Predictions</h4>
                    <LivePredictions 
                      gameId={upcomingGames[0].id} 
                      predictions={predictions} 
                      showTitle={false}
                    />
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* All Predictions Activity Feed */}
          <AllPredictionsFeed predictions={predictions} games={games} />

          {/* Completed Games with Winner Highlights */}
          {completedGames.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-[#041e42]">
                  <Trophy className="w-5 h-5" />
                  Completed Games
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {completedGames.slice(0, 6).map((game) => (
                    <CompletedGameCard
                      key={game.id}
                      game={game}
                      predictions={predictions.filter(p => p.game_id === game.id)}
                      onFilterChange={handleFilterChange}
                      activeFilters={filters}
                    />
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {games.length > 0 && filteredGames.length === 0 && (
            <Card>
              <CardContent className="text-center py-12">
                <h3 className="text-xl font-semibold text-[#041e42] mb-2">
                  No Matching Games Found
                </h3>
                <p className="text-[#75787b] mb-4">
                  Clear your filters to see all games.
                </p>
                <Button onClick={() => setFilters({ sport: null, gender: null, level: null })}>
                  Clear Filters
                </Button>
              </CardContent>
            </Card>
          )}
          
          {games.length === 0 && (
            <Card>
              <CardContent className="text-center py-12">
                <Trophy className="w-16 h-16 text-[#75787b] mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-[#041e42] mb-2">
                  No Games Scheduled
                </h3>
                <p className="text-[#75787b]">
                  Games will appear here once the admin schedules them.
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="predictions">
          <MyPredictions 
            predictions={predictions} 
            games={games}
            currentUser={currentUser}
            onUpdatePrediction={handleUpdateSelect} // Pass down the new handler
          />
        </TabsContent>

        <TabsContent value="stats">
          <StatsOverview predictions={predictions} games={games} />
        </TabsContent>
      </Tabs>

      {/* Prediction Form Modal */}
      {showPredictionForm && selectedGame && (
        <PredictionForm
          game={selectedGame}
          predictionToEdit={editingPrediction} // Pass the prediction to edit
          onSubmit={handlePredictionSubmitted}
          onCancel={() => {
            setShowPredictionForm(false);
            setSelectedGame(null);
            setEditingPrediction(null); // Clear editing state on cancel
          }}
        />
      )}
    </div>
  );
}
