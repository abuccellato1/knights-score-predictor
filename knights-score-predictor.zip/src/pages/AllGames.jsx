import React, { useState, useEffect } from "react";
import { Game, Prediction } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Calendar, Clock, Trophy, Filter } from "lucide-react";
import { format, isAfter } from "date-fns";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

import GameCard from "../components/home/GameCard";
import PredictionForm from "../components/home/PredictionForm";
import { User } from "@/api/entities";

export default function AllGames() {
  const [games, setGames] = useState([]);
  const [predictions, setPredictions] = useState([]);
  const [selectedGame, setSelectedGame] = useState(null);
  const [showPredictionForm, setShowPredictionForm] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState("all");
  const [sportFilter, setSportFilter] = useState("all");

  useEffect(() => {
    const loadAllData = async () => {
      setLoading(true);
      try {
        const user = await User.me();
        setCurrentUser(user);
      } catch (error) {
        setCurrentUser(null);
      } finally {
        await loadData();
        setLoading(false);
      }
    };
    
    loadAllData();
  }, []);

  const loadData = async () => {
    try {
      const [gamesData, predictionsData] = await Promise.all([
        Game.list('-game_date'),
        Prediction.list('-submitted_at')
      ]);
      setGames(gamesData);
      setPredictions(predictionsData);
    } catch (error) {
      console.error('Error loading data:', error);
    }
  };

  const handleGameSelect = (game) => {
    if (!currentUser) {
      try {
        User.loginWithRedirect(window.location.href);
      } catch (error) {
        console.error("Login redirect failed:", error);
      }
    } else {
      setSelectedGame(game);
      setShowPredictionForm(true);
    }
  };

  const handlePredictionSubmitted = (newPrediction) => {
    setPredictions(prev => [newPrediction, ...prev]);
    setShowPredictionForm(false);
    setSelectedGame(null);
    loadData();
  };

  // Filter games
  const filteredGames = games.filter(game => {
    const statusMatch = statusFilter === "all" || 
      (statusFilter === "open" && game.status === 'scheduled' && isAfter(new Date(game.cutoff_time), new Date())) ||
      (statusFilter === "closed" && (game.status === 'completed' || !isAfter(new Date(game.cutoff_time), new Date()))) ||
      (statusFilter === "active" && game.status === 'active') ||
      (statusFilter === "completed" && game.status === 'completed');
    
    const sportMatch = sportFilter === "all" || game.sport === sportFilter;
    
    return statusMatch && sportMatch;
  });

  // Get unique sports for filter
  const uniqueSports = [...new Set(games.map(g => g.sport))];

  if (loading) {
    return (
      <div className="max-w-6xl mx-auto p-4">
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#041e42] mx-auto mb-4"></div>
          <p className="text-[#75787b]">Loading games...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto p-4">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-4">
          <Button variant="outline" size="sm" asChild>
            <Link to={createPageUrl("Home")} className="flex items-center gap-2">
              <ArrowLeft className="w-4 h-4" />
              Back to Home
            </Link>
          </Button>
          <div>
            <h2 className="text-3xl font-bold text-[#041e42]">All Games</h2>
            <p className="text-[#75787b]">{filteredGames.length} games found</p>
          </div>
        </div>
      </div>

      {/* Filters */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="w-5 h-5" />
            Filter Games
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Status</label>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Games</SelectItem>
                  <SelectItem value="open">Open for Predictions</SelectItem>
                  <SelectItem value="active">Live Games</SelectItem>
                  <SelectItem value="closed">Predictions Closed</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Sport</label>
              <Select value={sportFilter} onValueChange={setSportFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter by sport" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Sports</SelectItem>
                  {uniqueSports.map(sport => (
                    <SelectItem key={sport} value={sport}>{sport}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Games Grid */}
      {filteredGames.length > 0 ? (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {filteredGames.map((game) => {
            const isOpen = game.status === 'scheduled' && isAfter(new Date(game.cutoff_time), new Date());
            
            return (
              <GameCard
                key={game.id}
                game={game}
                onPredict={isOpen ? () => handleGameSelect(game) : undefined}
                predictions={predictions.filter(p => p.game_id === game.id)}
                allPredictions={predictions}
                canPredict={isOpen}
                onFilterChange={() => {}} // No filter change needed here
                activeFilters={{}}
                compact={true}
              />
            );
          })}
        </div>
      ) : (
        <Card>
          <CardContent className="text-center py-12">
            <Trophy className="w-16 h-16 text-[#75787b] mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-[#041e42] mb-2">
              No Games Found
            </h3>
            <p className="text-[#75787b] mb-4">
              Try adjusting your filters or check back later for new games.
            </p>
            <div className="flex gap-2 justify-center">
              <Button variant="outline" onClick={() => setStatusFilter("all")}>
                Clear Status Filter
              </Button>
              <Button variant="outline" onClick={() => setSportFilter("all")}>
                Clear Sport Filter
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Prediction Form Modal */}
      {showPredictionForm && selectedGame && (
        <PredictionForm
          game={selectedGame}
          onSubmit={handlePredictionSubmitted}
          onCancel={() => {
            setShowPredictionForm(false);
            setSelectedGame(null);
          }}
        />
      )}
    </div>
  );
}